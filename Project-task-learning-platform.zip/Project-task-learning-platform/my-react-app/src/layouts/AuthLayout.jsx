import { Outlet, Link } from "react-router-dom";

import {
  Sparkles,
  BrainCircuit,
  GraduationCap,
  Trophy,
  ArrowRight,
  PlayCircle,
  CheckCircle2,
} from "lucide-react";

import { motion } from "framer-motion";

function AuthLayout() {
  return (
    <div
      className="
        relative

        min-h-screen

        overflow-hidden

        bg-[#050816]

        text-white
      "
    >

      {/* ================= BACKGROUND GLOW ================= */}

      <div
        className="
          absolute
          top-[-120px]
          left-[-100px]

          w-[450px]
          h-[450px]

          bg-blue-500/20

          blur-[140px]

          rounded-full
        "
      />

      <div
        className="
          absolute
          bottom-[-120px]
          right-[-100px]

          w-[450px]
          h-[450px]

          bg-pink-500/20

          blur-[140px]

          rounded-full
        "
      />

      {/* ================= MAIN GRID ================= */}

      <div
        className="
          relative
          z-10

          min-h-screen

          grid
          lg:grid-cols-2
        "
      >

        {/* ================= LEFT SIDE ================= */}

        <div
          className="
            hidden
            lg:flex

            flex-col
            justify-between

            p-14
            xl:p-20

            border-r
            border-white/10
          "
        >

          {/* TOP */}

          <div>

            {/* Logo */}

            <Link
              to="/"

              className="
                inline-flex
                items-center
                gap-3

                mb-16
              "
            >

              <div
                className="
                  w-14
                  h-14

                  rounded-2xl

                  bg-gradient-to-r
                  from-blue-500
                  to-purple-600

                  flex
                  items-center
                  justify-center

                  shadow-[0_0_40px_rgba(59,130,246,0.35)]
                "
              >

                <BrainCircuit size={28} />

              </div>

              <div>

               <div className="flex flex-col">
  <h1
    className="
      text-4xl font-black tracking-tight
      bg-gradient-to-r
      from-orange-400
      via-pink-500
      to-cyan-400
      bg-clip-text
      text-transparent
    "
  >
    UpToSkills
  </h1>

  <span className="text-xs tracking-wide text-cyan-300">
    Let's Make Freshers Employable!
  </span>
</div>

                <p className="text-slate-400 text-sm">
                  AI Learning Platform
                </p>

              </div>

            </Link>

            {/* Badge */}

            <div
              className="
                inline-flex
                items-center
                gap-2

                px-5
                py-3

                rounded-full

                bg-white/5

                border
                border-white/10

                backdrop-blur-xl

                mb-10
              "
            >

              <Sparkles
                size={18}
                className="text-cyan-400"
              />

              <span className="text-cyan-400 font-medium">
                Future-Ready AI Learning
              </span>

            </div>

            {/* Heading */}

            <motion.h1
              initial={{
                opacity: 0,
                y: 20,
              }}

              animate={{
                opacity: 1,
                y: 0,
              }}

              transition={{
                duration: 0.7,
              }}

              className="
                text-6xl
                xl:text-7xl

                font-black

                leading-tight

                mb-8
              "
            >

              Learn AI Skills
              <br />

              <span
                className="
                  bg-gradient-to-r
                  from-cyan-400
                  via-blue-500
                  to-purple-500

                  bg-clip-text
                  text-transparent
                "
              >
                That Actually Matter
              </span>

            </motion.h1>

            {/* Subtitle */}

            <p
              className="
                text-slate-400
                text-xl

                leading-10

                max-w-2xl

                mb-14
              "
            >
              Join thousands of learners mastering
              Artificial Intelligence, Machine Learning,
              Deep Learning, and Generative AI
              through immersive learning experiences.
            </p>

            {/* Features */}

            <div className="space-y-6">

              {/* Feature */}

              {[
                {
                  icon: "🚀",
                  title: "Real Industry Projects",
                  text:
                    "Build production-grade AI applications and ML systems.",
                },

                {
                  icon: "📚",
                  title: "Structured Learning Paths",
                  text:
                    "Master AI from fundamentals to advanced deployment.",
                },

                {
                  icon: "🎓",
                  title: "Career Support & Certifications",
                  text:
                    "Resume reviews, mentorship, and interview preparation.",
                },
              ].map((item, index) => (
                <motion.div
                  key={index}

                  whileHover={{
                    x: 10,
                  }}

                  className="
                    flex
                    items-start
                    gap-5

                    rounded-[28px]

                    bg-white/5

                    border
                    border-white/10

                    backdrop-blur-xl

                    p-6

                    hover:bg-white/10

                    transition-all
                    duration-300
                  "
                >

                  {/* Emoji */}

                  <div className="text-4xl">
                    {item.icon}
                  </div>

                  {/* Text */}

                  <div>

                    <h3
                      className="
                        text-2xl
                        font-bold

                        mb-2
                      "
                    >
                      {item.title}
                    </h3>

                    <p
                      className="
                        text-slate-400

                        leading-7
                      "
                    >
                      {item.text}
                    </p>

                  </div>

                </motion.div>
              ))}

            </div>

          </div>

          {/* BOTTOM STATS */}

          <div
            className="
              mt-14

              grid
              grid-cols-3

              gap-6
            "
          >

            {/* Card */}

            <div
              className="
                rounded-[28px]

                bg-white/5

                border
                border-white/10

                p-6

                text-center
              "
            >

              <GraduationCap
                size={30}
                className="
                  mx-auto
                  mb-4

                  text-cyan-400
                "
              />

              <h3
                className="
                  text-4xl
                  font-black

                  mb-2
                "
              >
                50K+
              </h3>

              <p className="text-slate-500">
                Students
              </p>

            </div>

            {/* Card */}

            <div
              className="
                rounded-[28px]

                bg-white/5

                border
                border-white/10

                p-6

                text-center
              "
            >

              <PlayCircle
                size={30}
                className="
                  mx-auto
                  mb-4

                  text-pink-400
                "
              />

              <h3
                className="
                  text-4xl
                  font-black

                  mb-2
                "
              >
                120+
              </h3>

              <p className="text-slate-500">
                Courses
              </p>

            </div>

            {/* Card */}

            <div
              className="
                rounded-[28px]

                bg-white/5

                border
                border-white/10

                p-6

                text-center
              "
            >

              <Trophy
                size={30}
                className="
                  mx-auto
                  mb-4

                  text-yellow-400
                "
              />

              <h3
                className="
                  text-4xl
                  font-black

                  mb-2
                "
              >
                95%
              </h3>

              <p className="text-slate-500">
                Success
              </p>

            </div>

          </div>

        </div>

        {/* ================= RIGHT SIDE ================= */}

        <div
          className="
            relative

            flex
            items-center
            justify-center

            px-6
            py-10

            lg:px-14
          "
        >

          {/* Glow */}

          <div
            className="
              absolute

              w-[400px]
              h-[400px]

              bg-blue-500/10

              blur-[120px]

              rounded-full
            "
          />

          {/* Auth Card */}

          <motion.div
            initial={{
              opacity: 0,
              scale: 0.95,
            }}

            animate={{
              opacity: 1,
              scale: 1,
            }}

            transition={{
              duration: 0.5,
            }}

            className="
              relative
              z-10

              w-full
              max-w-xl

              rounded-[40px]

              bg-white/5

              border
              border-white/10

              backdrop-blur-2xl

              p-8
              md:p-12

              shadow-[0_0_60px_rgba(59,130,246,0.18)]
            "
          >

            {/* Top Badge */}

            <div
              className="
                inline-flex
                items-center
                gap-2

                px-4
                py-2

                rounded-full

                bg-white/5

                border
                border-white/10

                mb-8
              "
            >

              <CheckCircle2
                size={16}
                className="text-green-400"
              />

              <span className="text-slate-300 text-sm">
                Secure Authentication
              </span>

            </div>

            {/* Outlet */}

            <Outlet />

            {/* Footer */}

            <div
              className="
                mt-10
                pt-8

                border-t
                border-white/10

                flex
                items-center
                justify-between

                text-sm
                text-slate-500
              "
            >

              <span>
                © 2026 LearnSphere
              </span>

              <button
                className="
                  flex
                  items-center
                  gap-2

                  text-cyan-400

                  hover:text-cyan-300

                  transition
                "
              >

                Need Help?

                <ArrowRight size={16} />

              </button>

            </div>

          </motion.div>

        </div>

      </div>

    </div>
  );
}

export default AuthLayout;