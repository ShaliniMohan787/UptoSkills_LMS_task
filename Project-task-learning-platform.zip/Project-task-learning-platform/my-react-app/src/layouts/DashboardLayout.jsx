import {
  Outlet,
  NavLink,
  Link,
  useNavigate,
} from "react-router-dom";

import {
  LayoutDashboard,
  BookOpen,
  User,
  ShieldCheck,
  BarChart3,
  Users,
  GraduationCap,
  LogOut,
  Bell,
  Search,
  Menu,
  Sparkles,
  BrainCircuit,
  ChevronRight,
} from "lucide-react";

import { motion } from "framer-motion";

function DashboardLayout() {
  const navigate = useNavigate();

  const role = localStorage.getItem("role");

  /* ================= ROLE BASED LINKS ================= */

  const studentLinks = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: LayoutDashboard,
      color: "text-cyan-400",
    },
    {
      name: "My Courses",
      path: "/dashboard/my-courses",
      icon: BookOpen,
      color: "text-pink-400",
    },
    {
      name: "Profile",
      path: "/dashboard/profile",
      icon: User,
      color: "text-yellow-400",
    },
  ];

  const adminLinks = [
    {
      name: "Dashboard",
      path: "/admin",
      icon: ShieldCheck,
      color: "text-green-400",
    },
    {
      name: "Analytics",
      path: "/admin/analytics",
      icon: BarChart3,
      color: "text-cyan-400",
    },
    {
      name: "Manage Users",
      path: "/admin/users",
      icon: Users,
      color: "text-pink-400",
    },
    {
      name: "Manage Courses",
      path: "/admin/courses",
      icon: GraduationCap,
      color: "text-yellow-400",
    },
  ];

  const links =
    role === "admin"
      ? adminLinks
      : studentLinks;

  /* ================= LOGOUT ================= */

  const handleLogout = () => {
    localStorage.removeItem("role");
    navigate("/login");
  };

  return (
    <div
      className="
        relative
        flex
        min-h-screen
        overflow-hidden
        bg-[#050816]
        text-white
      "
    >
      
      {/* ================= BACKGROUND ================= */}

      <div className="absolute left-[-100px] top-[-120px] h-[450px] w-[450px] rounded-full bg-blue-500/20 blur-[140px]" />

      <div className="absolute bottom-[-120px] right-[-100px] h-[450px] w-[450px] rounded-full bg-pink-500/20 blur-[140px]" />

      {/* ================= SIDEBAR ================= */}

      <aside
        className="
          relative z-10 hidden w-[320px]
          flex-col border-r border-white/10
          bg-[#08101F]/80 p-8
          backdrop-blur-2xl lg:flex
        "
      >
        
        {/* ================= LOGO ================= */}

        <Link
          to="/"
          className="mb-14 flex items-center gap-4"
        >
          
          <div
            className="
              flex h-16 w-16 items-center
              justify-center rounded-3xl
              bg-gradient-to-r
              from-blue-500 to-purple-600
              shadow-[0_0_40px_rgba(59,130,246,0.35)]
            "
          >
            <BrainCircuit size={30} />
          </div>

          <div>
            
            <h1 className="text-3xl font-black">
              {role === "admin"
                ? "UptoSkills Admin"
                : "UptoSkills"}
            </h1>

            <p className="text-sm text-slate-500">
              {role === "admin"
                ? "Admin Control Panel"
                : "AI Learning Platform"}
            </p>
          </div>
        </Link>

        {/* ================= BADGE ================= */}

        <div
          className="
            mb-10 inline-flex items-center gap-2
            rounded-2xl border border-white/10
            bg-white/5 px-4 py-3
          "
        >
          
          <Sparkles
            size={16}
            className="text-cyan-400"
          />

          <span className="font-medium text-cyan-400">
            {role === "admin"
              ? "Platform Management"
              : "Smart AI Dashboard"}
          </span>
        </div>

        {/* ================= NAVIGATION ================= */}

        <nav className="flex flex-col gap-4">
          
          {links.map((link) => {
            const Icon = link.icon;

            return (
              <NavLink
                key={link.name}
                to={link.path}
                className={({ isActive }) =>
                  `
                    group
                    flex items-center justify-between
                    rounded-[24px]
                    border px-6 py-5
                    transition-all duration-300

                    ${
                      isActive
                        ? `
                          border-blue-500/30
                          bg-gradient-to-r
                          from-blue-500/20
                          to-purple-500/20
                          shadow-[0_0_30px_rgba(59,130,246,0.15)]
                        `
                        : `
                          border-white/10
                          bg-white/5
                          hover:bg-white/10
                        `
                    }
                  `
                }
              >
                
                <div className="flex items-center gap-4">
                  
                  <Icon
                    size={22}
                    className={link.color}
                  />

                  <span className="text-lg font-medium">
                    {link.name}
                  </span>
                </div>

                <ChevronRight
                  size={18}
                  className="text-slate-500 transition group-hover:text-white"
                />
              </NavLink>
            );
          })}
        </nav>

        {/* ================= PROFILE ================= */}

        <div className="mt-auto pt-10">
          
          <div
            className="
              mb-6 flex items-center gap-4
              rounded-[28px] border
              border-white/10 bg-white/5 p-5
            "
          >
            
            <img
              src="https://i.pravatar.cc/150"
              alt="profile"
              className="h-16 w-16 rounded-2xl"
            />

            <div>
              
              <h4 className="text-lg font-semibold">
                John Doe
              </h4>

              <p className="text-slate-500">
                {role === "admin"
                  ? "Platform Admin"
                  : "AI Engineer"}
              </p>
            </div>
          </div>

          {/* Logout */}

          <button
            onClick={handleLogout}
            className="
              flex w-full items-center
              justify-center gap-3
              rounded-[24px]
              bg-gradient-to-r
              from-red-500 to-pink-600
              py-5 text-lg font-semibold
              text-white
              shadow-[0_0_40px_rgba(239,68,68,0.25)]
              transition-all
              hover:scale-[1.02]
            "
          >
            
            <LogOut size={22} />

            Logout
          </button>
        </div>
      </aside>

      {/* ================= MAIN CONTENT ================= */}

      <div className="relative z-10 flex flex-1 flex-col">
        
        {/* ================= TOPBAR ================= */}

        <header
          className="
            sticky top-0 z-20
            border-b border-white/10
            bg-[#08101F]/80
            px-6 py-6 backdrop-blur-2xl
            lg:px-10
          "
        >
          
          <div className="flex items-center justify-between gap-6">
            
            {/* LEFT */}

            <div className="flex items-center gap-5">
              
              <button
                className="
                  flex h-14 w-14 items-center
                  justify-center rounded-2xl
                  border border-white/10
                  bg-white/5 lg:hidden
                "
              >
                <Menu size={24} />
              </button>

              {/* SEARCH */}

              <div
                className="
                  hidden min-w-[380px]
                  items-center gap-4
                  rounded-2xl border
                  border-white/10
                  bg-white/5 px-5 py-4 md:flex
                "
              >
                
                <Search
                  size={20}
                  className="text-cyan-400"
                />

                <input
                  type="text"
                  placeholder="Search AI courses..."
                  className="
                    w-full bg-transparent
                    text-white
                    placeholder:text-slate-500
                    outline-none
                  "
                />
              </div>
            </div>

            {/* RIGHT */}

            <div className="flex items-center gap-5">
              
              {/* Notification */}

              <button
                className="
                  relative flex h-14 w-14
                  items-center justify-center
                  rounded-2xl border
                  border-white/10 bg-white/5
                  transition hover:bg-white/10
                "
              >
                
                <Bell size={22} />

                <span
                  className="
                    absolute right-3 top-3
                    h-3 w-3 rounded-full
                    bg-pink-500
                  "
                />
              </button>

              {/* User */}

              <motion.div
                whileHover={{
                  scale: 1.03,
                }}
                className="
                  flex items-center gap-4
                  rounded-[24px]
                  border border-white/10
                  bg-white/5 px-5 py-3
                "
              >
                
                <div className="hidden sm:block">
                  
                  <h4 className="font-semibold">
                    John Doe
                  </h4>

                  <p className="text-sm text-slate-500">
                    {role === "admin"
                      ? "Platform Admin"
                      : "AI Engineer"}
                  </p>
                </div>

                <img
                  src="https://i.pravatar.cc/150"
                  alt="profile"
                  className="h-14 w-14 rounded-2xl"
                />
              </motion.div>
            </div>
          </div>
        </header>

        {/* ================= PAGE CONTENT ================= */}

        <main className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export default DashboardLayout;