import { Outlet } from "react-router-dom";

import { motion } from "framer-motion";

import Navbar from "../components/Navbar/Navbar";
import Footer from "../components/Footer/Footer";

function MainLayout() {
  return (
    <div
      className="
        relative

        min-h-screen

        overflow-hidden

        bg-[#050816]

        text-white

        flex
        flex-col
      "
    >

      {/* ================= GLOBAL BACKGROUND ================= */}

      {/* TOP LEFT GLOW */}

      <div
        className="
          fixed
          top-[-180px]
          left-[-140px]

          w-[520px]
          h-[520px]

          bg-blue-500/20

          blur-[160px]

          rounded-full

          pointer-events-none
        "
      />

      {/* TOP RIGHT GLOW */}

      <div
        className="
          fixed
          top-[120px]
          right-[-180px]

          w-[500px]
          h-[500px]

          bg-purple-500/20

          blur-[160px]

          rounded-full

          pointer-events-none
        "
      />

      {/* BOTTOM GLOW */}

      <div
        className="
          fixed
          bottom-[-200px]
          left-[25%]

          w-[650px]
          h-[650px]

          bg-pink-500/10

          blur-[180px]

          rounded-full

          pointer-events-none
        "
      />

      {/* GRID EFFECT */}

      <div
        className="
          fixed
          inset-0

          opacity-[0.03]

          pointer-events-none
        "

        style={{
          backgroundImage: `
            linear-gradient(to right, white 1px, transparent 1px),
            linear-gradient(to bottom, white 1px, transparent 1px)
          `,
          backgroundSize: "70px 70px",
        }}
      />

      {/* ================= FLOATING PARTICLES ================= */}

      <motion.div
        animate={{
          y: [0, -20, 0],
        }}

        transition={{
          duration: 6,
          repeat: Infinity,
        }}

        className="
          fixed
          top-[20%]
          left-[8%]

          w-4
          h-4

          rounded-full

          bg-cyan-400/40

          blur-sm

          pointer-events-none
        "
      />

      <motion.div
        animate={{
          y: [0, 25, 0],
        }}

        transition={{
          duration: 8,
          repeat: Infinity,
        }}

        className="
          fixed
          top-[65%]
          right-[12%]

          w-5
          h-5

          rounded-full

          bg-pink-400/40

          blur-sm

          pointer-events-none
        "
      />

      <motion.div
        animate={{
          y: [0, -15, 0],
        }}

        transition={{
          duration: 7,
          repeat: Infinity,
        }}

        className="
          fixed
          bottom-[18%]
          left-[18%]

          w-3
          h-3

          rounded-full

          bg-blue-400/40

          blur-sm

          pointer-events-none
        "
      />

      {/* ================= NAVBAR ================= */}

      <div className="relative z-50">
        <Navbar />
      </div>

      {/* ================= MAIN CONTENT ================= */}

      <main
        className="
          relative
          z-10

          flex-1
        "
      >

        <motion.div
          initial={{
            opacity: 0,
            y: 20,
          }}

          animate={{
            opacity: 1,
            y: 0,
          }}

          transition={{
            duration: 0.5,
          }}
        >

          <Outlet />

        </motion.div>

      </main>

      {/* ================= FOOTER ================= */}

      <div className="relative z-10">
        <Footer />
      </div>

    </div>
  );
}

export default MainLayout;