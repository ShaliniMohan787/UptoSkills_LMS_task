import { useEffect, useRef, useState } from "react";

import { Link } from "react-router-dom";

import {
  Search,
  Menu,
  LogIn,
  Sparkles,
  X,
} from "lucide-react";

import allMentors from "../../data/allMentors";

const navLink = `
  text-slate-300
  hover:text-cyan-400
  transition-all duration-300
  font-medium text-sm
`;

function Navbar() {

  const [search, setSearch] =
    useState("");

  const [mobileMenu, setMobileMenu] =
    useState(false);

  const searchRef = useRef(null);

  /* ============================================= */
  /* CLOSE SEARCH ON OUTSIDE CLICK */
  /* ============================================= */

  useEffect(() => {

    function handleClickOutside(event) {

      if (
        searchRef.current &&
        !searchRef.current.contains(event.target)
      ) {
        setSearch("");
      }
    }

    document.addEventListener(
      "mousedown",
      handleClickOutside
    );

    return () =>
      document.removeEventListener(
        "mousedown",
        handleClickOutside
      );
  }, []);

  /* ============================================= */
  /* FILTER */
  /* ============================================= */

  const filteredMentors =
  Object.values(allMentors).filter((mentor) =>
    mentor.mentor
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <header
      className="
        fixed top-0 left-0 z-50
        w-full border-b border-white/10
        bg-[#050816]/80
        backdrop-blur-2xl
      "
    >

      {/* Glow */}

      <div
        className="
          absolute left-1/4 top-0
          h-24 w-24
          rounded-full
          bg-cyan-500/10
          blur-[70px]
        "
      />

      <nav
        className="
          relative z-10
          mx-auto flex max-w-7xl
          items-center justify-between
          gap-6 px-6 py-4
        "
      >

        {/* ============================================= */}
        {/* LEFT */}
        {/* ============================================= */}

        <div className="flex items-center gap-5">

          {/* Mobile Menu */}

          <button
            onClick={() =>
              setMobileMenu(!mobileMenu)
            }
            className="
              rounded-xl border border-white/10
              bg-white/5 p-2 text-white
              transition hover:bg-white/10
              lg:hidden
            "
          >

            {mobileMenu ? (
              <X size={22} />
            ) : (
              <Menu size={22} />
            )}
          </button>

          {/* Logo */}

          <Link
            to="/"
            className="
              text-2xl font-black
              tracking-tight
              md:text-3xl
            "
          >

           <div className="flex flex-col">
  <h1
    className="
      text-4xl font-black tracking-tight
      bg-gradient-to-r
      from-orange-400
      via-pink-500
      to-cyan-400
      bg-clip-text
      text-transparent
    "
  >
    UpToSkills
  </h1>

  <span className="text-xs tracking-wide text-cyan-300">
    Let's Make Freshers Employable!
  </span>
</div>
          </Link>
        </div>

        {/* ============================================= */}
        {/* SEARCH */}
        {/* ============================================= */}

        <div
          ref={searchRef}
          className="
            relative hidden
            flex-1 lg:block
          "
        >

          {/* Search Bar */}

          <div
            className="
              flex items-center gap-3
              rounded-2xl
              border border-white/10
              bg-white/5 px-5 py-3
              backdrop-blur-xl
              transition-all duration-300
              focus-within:border-cyan-400/30
              focus-within:shadow-[0_0_30px_rgba(34,211,238,0.15)]
            "
          >

            <Search
              size={18}
              className="text-slate-400"
            />

            <input
              type="text"

              value={search}

              onChange={(e) =>
                setSearch(e.target.value)
              }

              placeholder="
                Search celebrities, mentors, AI skills...
              "

              className="
                w-full bg-transparent
                text-sm text-white
                outline-none
                placeholder:text-slate-500
              "
            />

            {search && (
              <button
                onClick={() => setSearch("")}
                className="
                  text-slate-400
                  hover:text-white
                "
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* ============================================= */}
          {/* SEARCH RESULTS */}
          {/* ============================================= */}

          {search && (
            <div
              className="
                absolute left-0 top-16
                max-h-[450px] w-full
                overflow-y-auto
                rounded-3xl
                border border-white/10
                bg-[#0B1120]/95 p-3
                backdrop-blur-2xl
                shadow-2xl
              "
            >

              {filteredMentors.length > 0 ? (

                filteredMentors.map((mentor) => (

                  <Link
                    key={mentor.id}

                    to={`/courses/${mentor.id}`}

                    onClick={() =>
                      setSearch("")
                    }

                    className="
                      mb-2 block rounded-2xl
                      border border-transparent
                      bg-white/5 p-4
                      transition-all duration-300
                      hover:border-cyan-400/20
                      hover:bg-white/10
                      hover:scale-[1.01]
                    "
                  >

                    <div className="flex items-center gap-4">

                      {/* Image */}

                      <img
                        src={mentor.image}
                        alt={mentor.mentor}
                        className="
                          h-14 w-14 rounded-2xl
                          object-cover
                          border border-cyan-400/20
                        "
                      />

                      {/* Content */}

                      <div className="flex-1">

                        <h3
                          className="
                            text-sm font-semibold
                            text-white
                          "
                        >
                          {mentor.mentor}
                        </h3>

                        <p
                          className="
                            mt-1 text-xs
                            text-slate-400
                          "
                        >
                          {mentor.course}
                        </p>

                        <span
                          className="
                            mt-2 inline-flex
                            rounded-full
                            bg-cyan-500/10
                            px-3 py-1
                            text-[11px]
                            font-medium
                            text-cyan-400
                          "
                        >
                          {mentor.category}
                        </span>
                      </div>

                      <Sparkles
                        size={18}
                        className="
                          text-cyan-400
                        "
                      />
                    </div>
                  </Link>
                ))

              ) : (

                <div
                  className="
                    rounded-2xl bg-white/5
                    p-6 text-center
                  "
                >

                  <p className="text-sm text-slate-400">
                    No mentors found
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ============================================= */}
        {/* RIGHT MENU */}
        {/* ============================================= */}

        <div className="hidden items-center gap-6 md:flex">

          <Link
            to="/courses"
            className={navLink}
          >
            Mentors
          </Link>

          <Link
            to="/dashboard"
            className={navLink}
          >
            Dashboard
          </Link>

          <Link
            to="/login"

            className="
              flex items-center gap-2
              rounded-xl
              bg-gradient-to-r
              from-blue-500 to-purple-600
              px-5 py-3
              text-sm font-semibold text-white
              shadow-[0_0_25px_rgba(59,130,246,0.35)]
              transition-all duration-300
              hover:scale-[1.03]
            "
          >

            <LogIn size={16} />

            Login
          </Link>
        </div>
      </nav>

      {/* ============================================= */}
      {/* MOBILE MENU */}
      {/* ============================================= */}

      {mobileMenu && (

        <div
          className="
            border-t border-white/10
            bg-[#050816]
            px-6 py-5
            md:hidden
          "
        >

          <div className="flex flex-col gap-5">

            <Link
              to="/courses"
              className={navLink}
            >
              Mentors
            </Link>

            <Link
              to="/dashboard"
              className={navLink}
            >
              Dashboard
            </Link>

            <Link
              to="/login"

              className="
                flex items-center
                justify-center gap-2
                rounded-xl
                bg-gradient-to-r
                from-blue-500
                to-purple-600
                px-5 py-3
                text-sm font-semibold text-white
              "
            >

              <LogIn size={16} />

              Login
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

export default Navbar;