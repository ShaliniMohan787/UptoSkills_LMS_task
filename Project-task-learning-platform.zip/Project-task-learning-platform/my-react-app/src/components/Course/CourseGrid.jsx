import CourseCard from "./CourseCard";

import {
  Sparkles,
  ArrowRight,
} from "lucide-react";

import allMentors from "../../data/allMentors";

const CourseGrid = () => {
  return (
    <section className="relative py-20 px-6 bg-[#0f172a] overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 left-0 w-72 h-72 bg-cyan-500/20 blur-3xl rounded-full"></div>

      <div className="absolute bottom-0 right-0 w-72 h-72 bg-purple-500/20 blur-3xl rounded-full"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-14">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/10 text-cyan-400 text-sm mb-5 backdrop-blur-md">
              <Sparkles size={16} />
              World-Class Mentors
            </div>

            <h2 className="text-4xl md:text-5xl font-extrabold text-white leading-tight">
              Learn From
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                {" "}
                Legends
              </span>
            </h2>

            <p className="text-gray-400 mt-4 max-w-2xl">
              Unlock elite knowledge from innovators,
              athletes, creators, scientists, and leaders.
            </p>
          </div>

          {/* View All Button */}
          <button className="mt-8 md:mt-0 group flex items-center gap-2 px-6 py-3 rounded-xl bg-white/10 hover:bg-cyan-500 transition-all duration-300 text-white border border-white/10">
            Explore All
            <ArrowRight
              size={18}
              className="group-hover:translate-x-1 transition-transform"
            />
          </button>
        </div>


        {/* Course Grid */}
       <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
  {Object.values(allMentors).map((mentor) => (
    <CourseCard
      key={mentor.id}
      course={{
        id: mentor.id,

        mentor: mentor.mentor,

        role: mentor.role,

        title:
          mentor.title ||
          mentor.course,

        category: mentor.category,

        students:
          mentor.students ||
          "10K+",

        duration:
          mentor.duration ||
          "8 Weeks",

        level:
          mentor.level ||
          "Intermediate",

        price:
          mentor.price ||
          "₹4,999",

        image: mentor.image,

        mentorImage:
          mentor.mentorImage ||
          mentor.image,
      }}
    />
  ))}
</div>
      </div>
    </section>
  );
};

export default CourseGrid;