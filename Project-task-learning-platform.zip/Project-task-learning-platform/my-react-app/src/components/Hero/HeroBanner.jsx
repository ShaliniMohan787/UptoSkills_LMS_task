import { motion } from "framer-motion";
import { ArrowRight, Play } from "lucide-react";


const floatingCard =
  "absolute rounded-3xl border border-white/10 bg-[#0B1120]/90 px-6 py-5 backdrop-blur-xl shadow-2xl";

function HeroBanner() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden bg-[#050816] pt-32">
      
      {/* Background Glow */}
      <div className="absolute -left-32 -top-40 h-[500px] w-[500px] rounded-full bg-blue-500/20 blur-[140px]" />

      <div className="absolute -bottom-40 -right-32 h-[450px] w-[450px] rounded-full bg-pink-500/20 blur-[140px]" />

      {/* Main Container */}
      <div className="relative z-10 mx-auto grid max-w-[1700px] items-center gap-20 px-8 lg:grid-cols-2">
        
        {/* Left Content */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          
          {/* Badge */}
          <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-5 py-2 backdrop-blur-xl">
            <span className="h-2 w-2 rounded-full bg-cyan-400" />

            <p className="font-medium text-cyan-400">
              #1 AI Learning Platform
            </p>
          </div>

          {/* Heading */}
          <h1 className="mb-6 text-5xl font-extrabold leading-tight tracking-tight md:text-6xl lg:text-7xl">
            
            <span className="bg-gradient-to-r from-orange-400 via-pink-500 to-blue-500 bg-clip-text text-transparent">
              Learn AI & Data Science
            </span>

            <br />

            <span className="text-white">
              From Industry Experts
            </span>
          </h1>

          {/* Description */}
          <p className="mb-10 max-w-2xl text-lg leading-8 text-slate-400 md:text-xl">
            Master Machine Learning, Deep Learning, Generative AI,
            NLP, and Data Analytics with hands-on projects,
            mentorship, and real-world workflows.
          </p>

          {/* Buttons */}
          <div className="flex flex-wrap items-center gap-5">
            
            {/* Primary Button */}
            <button className="flex items-center gap-3 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-600 px-8 py-4 text-lg font-semibold text-white shadow-[0_0_40px_rgba(59,130,246,0.35)] transition-all duration-300 hover:scale-105">
              Explore Courses
              <ArrowRight size={20} />
            </button>

            {/* Secondary Button */}
            <button className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-8 py-4 text-lg font-medium text-white backdrop-blur-xl transition-all duration-300 hover:bg-white/10">
              <Play size={18} />
              Watch Demo
            </button>
          </div>

          
        </motion.div>

        {/* Right Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          
          {/* Glow */}
          <div className="absolute inset-0 rounded-full bg-blue-500/20 blur-[120px]" />

          {/* Main Image */}
          <div className="relative overflow-hidden rounded-[40px] border border-white/10 bg-white/5 shadow-2xl backdrop-blur-xl">
            <img
              src="https://images.unsplash.com/photo-1677442136019-21780ecad995"
              alt="AI Learning"
              className="h-full w-full object-cover"
            />
          </div>

          {/* Floating Card 1 */}
          <div className={`${floatingCard} -bottom-10 -left-10`}>
            <p className="mb-2 text-sm text-slate-400">
              AI Interview Prep
            </p>

            <h4 className="text-xl font-bold text-white">
              1,200+ Questions
            </h4>
          </div>

          {/* Floating Card 2 */}
          <div className={`${floatingCard} -top-10 right-0`}>
            <p className="mb-2 text-sm text-slate-400">
              Live Projects
            </p>

            <h4 className="text-xl font-bold text-white">
              25+ Industry Cases
            </h4>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export default HeroBanner;