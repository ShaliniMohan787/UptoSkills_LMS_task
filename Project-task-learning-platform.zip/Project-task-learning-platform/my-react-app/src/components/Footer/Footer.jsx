function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-14">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-10">

        {/* Brand */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4">
            LearnSphere
          </h2>

          <p>
            Empowering future AI engineers with practical,
            project-based learning.
          </p>
        </div>

        {/* Links */}
        <div>
          <h3 className="text-white font-semibold mb-4">
            Company
          </h3>

          <ul className="space-y-2">
            <li>About</li>
            <li>Careers</li>
            <li>Blog</li>
          </ul>
        </div>

        <div>
          <h3 className="text-white font-semibold mb-4">
            Courses
          </h3>

          <ul className="space-y-2">
            <li>Machine Learning</li>
            <li>Deep Learning</li>
            <li>Generative AI</li>
          </ul>
        </div>

        <div>
          <h3 className="text-white font-semibold mb-4">
            Support
          </h3>

          <ul className="space-y-2">
            <li>Help Center</li>
            <li>Contact</li>
            <li>Privacy Policy</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-slate-700 mt-12 pt-6 text-center text-sm">
        © 2026 LearnSphere. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;