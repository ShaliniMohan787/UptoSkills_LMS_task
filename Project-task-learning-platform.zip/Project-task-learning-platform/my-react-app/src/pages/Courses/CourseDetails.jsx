import {
  Clock3,
  PlayCircle,
  CheckCircle2,
  ArrowRight,
  BrainCircuit,
  Award,
  Sparkles,
  BookOpen,
  Lock,
} from "lucide-react";

import { motion } from "framer-motion";

import {
  useParams,
  useNavigate,
} from "react-router-dom";

import { useState, useEffect } from "react";

/* IMPORT ALL MENTORS */
import allMentors from "../../data/allMentors";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

function CourseDetails() {
  const { id } = useParams();

  const navigate = useNavigate();

  const [isEnrolled, setIsEnrolled] =
    useState(false);

  /* =========================
     FIX ARRAY / OBJECT ISSUE
  ========================== */

  const mentorsArray = Array.isArray(allMentors)
    ? allMentors
    : Object.keys(allMentors).map((key) => ({
        id: Number(key),
        ...allMentors[key],
      }));

  /* FIND COURSE USING ID */

  const course =
    mentorsArray.find(
      (mentor) => mentor.id === Number(id)
    ) || mentorsArray[0];

  /* DEFAULT MODULES */

  const modules =
    course.modules || [
      {
        id: 1,
        title: "Introduction",
        duration: "12 mins",
      },

      {
        id: 2,
        title: "Core Concepts",
        duration: "25 mins",
      },

      {
        id: 3,
        title: "Advanced Session",
        duration: "32 mins",
      },

      {
        id: 4,
        title: "Real World Projects",
        duration: "40 mins",
      },
    ];

  const [completedModules, setCompletedModules] =
    useState([]);

  const [playing, setPlaying] =
    useState(false);

  /* LOAD PROGRESS */

  useEffect(() => {
    const savedProgress =
      JSON.parse(
        localStorage.getItem(
          `course-progress-${id}`
        )
      ) || [];

    setCompletedModules(savedProgress);
  }, [id]);

  /* SAVE PROGRESS */

  useEffect(() => {
    localStorage.setItem(
      `course-progress-${id}`,
      JSON.stringify(completedModules)
    );
  }, [completedModules, id]);

  /* CHECK ENROLLMENT */

  useEffect(() => {
    const enrolled =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    setIsEnrolled(
      enrolled.includes(course.id)
    );
  }, [course.id]);

  /* TOGGLE MODULE */

  const toggleModule = (moduleId) => {
    if (completedModules.includes(moduleId)) {
      setCompletedModules(
        completedModules.filter(
          (item) => item !== moduleId
        )
      );
    } else {
      setCompletedModules([
        ...completedModules,
        moduleId,
      ]);
    }
  };

  /* ENROLL COURSE */

  const handleEnroll = () => {
    const enrolled =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    if (!enrolled.includes(course.id)) {
      const updated = [
        ...enrolled,
        course.id,
      ];

      localStorage.setItem(
        "enrolledCourses",
        JSON.stringify(updated)
      );

      setIsEnrolled(true);
    }
  };

  /* REMOVE COURSE */

  const handleRemove = () => {
    const enrolled =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    const updated = enrolled.filter(
      (courseId) =>
        courseId !== course.id
    );

    localStorage.setItem(
      "enrolledCourses",
      JSON.stringify(updated)
    );

    setIsEnrolled(false);

    navigate("/my-courses");
  };

  /* PROGRESS */

  const progress =
    modules.length > 0
      ? (completedModules.length /
          modules.length) *
        100
      : 0;

  return (
    <div
      className="
        min-h-screen bg-[#050816]
        px-6 pb-20 pt-24
        text-white
      "
    >
      <div className="mx-auto max-w-7xl">
        {/* HERO */}

        <div className="grid gap-12 lg:grid-cols-2">
          {/* LEFT */}

          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div
              className={`
                mb-5 inline-flex items-center
                gap-2 rounded-full px-4 py-2
                ${glass}
              `}
            >
              <Sparkles
                size={16}
                className="text-cyan-400"
              />

              <span className="text-sm">
                {course.category}
              </span>
            </div>

            <h1 className="mb-4 text-5xl font-black">
              {course.title ||
                course.course}
            </h1>

            <p className="mb-8 text-slate-400 leading-8">
              {course.description}
            </p>

            {/* MENTOR */}

            <div
              className={`
                mb-8 flex items-center gap-4
                rounded-3xl p-5 ${glass}
              `}
            >
              <img
                src={
                  course.mentorImage ||
                  course.image
                }
                alt={course.mentor}
                className="
                  h-16 w-16 rounded-full
                  object-cover
                "
              />

              <div>
                <h3 className="text-lg font-bold">
                  {course.mentor}
                </h3>

                <p className="text-slate-400">
                  {course.role ||
                    "AI Mentor"}
                </p>
              </div>
            </div>

            {/* PROGRESS */}

            <div className="mb-8">
              <div className="mb-2 flex justify-between">
                <span>Progress</span>

                <span>
                  {Math.round(progress)}%
                </span>
              </div>

              <div className="h-3 rounded-full bg-white/10">
                <div
                  className="
                    h-full rounded-full
                    bg-gradient-to-r
                    from-cyan-400 to-blue-500
                    transition-all duration-500
                  "
                  style={{
                    width: `${progress}%`,
                  }}
                />
              </div>
            </div>

            {/* BUTTONS */}

            <div className="flex flex-wrap gap-4">
              {!isEnrolled ? (
                <button
                  onClick={handleEnroll}
                  className="
                    flex items-center gap-2
                    rounded-xl
                    bg-gradient-to-r
                    from-green-500 to-emerald-600
                    px-6 py-3
                    font-medium
                    transition-all
                    hover:scale-105
                  "
                >
                  Enroll Now

                  <ArrowRight size={18} />
                </button>
              ) : (
                <>
                  <button
                    onClick={() =>
                      setPlaying(true)
                    }
                    className="
                      flex items-center gap-2
                      rounded-xl
                      bg-gradient-to-r
                      from-blue-500 to-purple-600
                      px-6 py-3
                      font-medium
                      transition-all
                      hover:scale-105
                    "
                  >
                    Start Session

                    <ArrowRight size={18} />
                  </button>

                  <button
                    onClick={handleRemove}
                    className="
                      rounded-xl
                      border border-red-500/20
                      bg-red-500/10
                      px-6 py-3
                      text-red-400
                      transition-all
                      hover:bg-red-500/20
                    "
                  >
                    Remove Course
                  </button>
                </>
              )}

              <button
                onClick={() =>
                  setPlaying(true)
                }
                className={`
                  flex items-center gap-2
                  rounded-xl px-6 py-3
                  transition-all
                  hover:bg-white/10
                  ${glass}
                `}
              >
                <PlayCircle size={18} />

                Watch Trailer
              </button>
            </div>
          </motion.div>

          {/* RIGHT */}

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div
              className={`
                overflow-hidden rounded-3xl
                ${glass}
              `}
            >
              {!playing ? (
                <div className="relative">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="
                       h-[500px] w-full object-contain
    bg-black
                    "
                  />

                  <button
                    onClick={() =>
                      setPlaying(true)
                    }
                    className="
                      absolute inset-0
                      flex items-center
                      justify-center
                      bg-black/30
                    "
                  >
                    <PlayCircle
                      size={80}
                      className="
                        text-white
                        transition-all
                        hover:scale-110
                      "
                    />
                  </button>
                </div>
              ) : (
                <iframe
                  className="h-[500px] w-full"
                  src={`${
                    course.trailer ||
                    "https://www.youtube.com/embed/dQw4w9WgXcQ"
                  }?autoplay=1`}
                  title={course.title}
                  allow="autoplay"
                  allowFullScreen
                />
              )}
            </div>
          </motion.div>
        </div>

        {/* INFO CARDS */}

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          <div
            className={`rounded-3xl p-6 ${glass}`}
          >
            <Clock3 className="mb-4 text-cyan-400" />

            <h3 className="mb-2 text-xl font-bold">
              {course.duration ||
                "12 Weeks"}
            </h3>

            <p className="text-slate-400">
              Structured learning roadmap.
            </p>
          </div>

          <div
            className={`rounded-3xl p-6 ${glass}`}
          >
            <BrainCircuit className="mb-4 text-pink-400" />

            <h3 className="mb-2 text-xl font-bold">
              AI Sessions
            </h3>

            <p className="text-slate-400">
              Interactive mentor
              experience.
            </p>
          </div>

          <div
            className={`rounded-3xl p-6 ${glass}`}
          >
            <Award className="mb-4 text-yellow-400" />

            <h3 className="mb-2 text-xl font-bold">
              Certification
            </h3>

            <p className="text-slate-400">
              Completion certificates
              included.
            </p>
          </div>
        </div>

        {/* MODULES */}

        <div
          className={`
            mt-16 rounded-3xl
            p-8 ${glass}
          `}
        >
          <h2 className="mb-6 text-3xl font-bold">
            Learning Modules
          </h2>

          <div className="space-y-4">
            {modules.map(
              (module, index) => {
                const completed =
                  completedModules.includes(
                    module.id
                  );

                return (
                  <div
                    key={module.id}
                    className="
                      flex flex-col gap-4
                      rounded-2xl
                      border border-white/10
                      bg-white/5 p-5
                      md:flex-row
                      md:items-center
                      md:justify-between
                    "
                  >
                    <div className="flex gap-4">
                      <div
                        className="
                          flex h-12 w-12
                          items-center justify-center
                          rounded-2xl
                          bg-blue-500/10
                        "
                      >
                        <BookOpen className="text-cyan-400" />
                      </div>

                      <div>
                        <h3 className="font-semibold">
                          {module.title}
                        </h3>

                        <p className="text-sm text-slate-500">
                          Module{" "}
                          {index + 1} •{" "}
                          {module.duration}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() =>
                        toggleModule(
                          module.id
                        )
                      }
                      className={`
                        rounded-xl px-4 py-2
                        text-sm font-medium
                        transition-all
                        ${
                          completed
                            ? "bg-green-500/20 text-green-400"
                            : "bg-white/10 text-slate-300"
                        }
                      `}
                    >
                      {completed ? (
                        <div className="flex items-center gap-2">
                          <CheckCircle2 size={18} />
                          Completed
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Lock size={18} />
                          Mark Complete
                        </div>
                      )}
                    </button>
                  </div>
                );
              }
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default CourseDetails;