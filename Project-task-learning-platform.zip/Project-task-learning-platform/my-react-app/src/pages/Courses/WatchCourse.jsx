import {
  PlayCircle,
  PauseCircle,
  Mic,
  BrainCircuit,
  BookOpen,
  MessageSquare,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Volume2,
} from "lucide-react";

import { motion } from "framer-motion";
import { useParams } from "react-router-dom";
import { useEffect, useRef, useState } from "react";

/* ====================================================== */
/* ================= COURSE DATA ======================== */
/* ====================================================== */

const courses = [
  {
    id: 1,
    mentor: "Elon Musk",
    role: "CEO of Tesla & SpaceX",
    title: "Future AI With Elon Musk",

    image:
      "https://upload.wikimedia.org/wikipedia/commons/e/ed/Elon_Musk_Royal_Society.jpg",

    video:
      "https://www.w3schools.com/html/mov_bbb.mp4",
  },

  {
    id: 2,
    mentor: "Virat Kohli",
    role: "World-Class Athlete",

    image:
      "https://upload.wikimedia.org/wikipedia/commons/7/7a/Virat_Kohli.jpg",

    video:
      "https://www.w3schools.com/html/movie.mp4",
  },

  {
    id: 3,
    mentor: "MS Dhoni",
    role: "Captain Cool",

    image:
      "https://upload.wikimedia.org/wikipedia/commons/9/98/MS_Dhoni.jpg",

    video:
      "https://www.w3schools.com/html/mov_bbb.mp4",
  },
];

/* ====================================================== */
/* ================= LESSONS ============================ */
/* ====================================================== */

const initialLessons = [
  {
    id: 1,
    title: "Introduction to Artificial Intelligence",
    completed: false,
  },

  {
    id: 2,
    title: "Neural Networks & Deep Learning",
    completed: false,
  },

  {
    id: 3,
    title: "Building AI Systems",
    completed: false,
  },

  {
    id: 4,
    title: "Natural Language Processing",
    completed: false,
  },

  {
    id: 5,
    title: "AI Deployment & Scaling",
    completed: false,
  },

  {
    id: 6,
    title: "Industry-Level AI Projects",
    completed: false,
  },
];

/* ====================================================== */

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

/* ====================================================== */
/* ================= COMPONENT ========================== */
/* ====================================================== */

function WatchCourse() {
  const { id } = useParams();

  const course =
    courses.find((c) => c.id === Number(id)) ||
    courses[0];

  /* ====================================================== */
  /* ================= VIDEO STATE ======================== */
  /* ====================================================== */

  const videoRef = useRef(null);

  const [isPlaying, setIsPlaying] =
    useState(false);

  const [progress, setProgress] =
    useState(0);

  const [volume, setVolume] = useState(1);

  /* ====================================================== */
  /* ================= LESSON STATE ======================= */
  /* ====================================================== */

  const [lessons, setLessons] =
    useState(initialLessons);

  /* ====================================================== */
  /* ================= VIDEO FUNCTIONS ==================== */
  /* ====================================================== */

  const togglePlay = () => {
    if (!videoRef.current) return;

    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }

    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;

    if (!video) return;

    const percentage =
      (video.currentTime / video.duration) * 100;

    setProgress(percentage || 0);
  };

  const handleVolume = (e) => {
    const value = e.target.value;

    setVolume(value);

    if (videoRef.current) {
      videoRef.current.volume = value;
    }
  };

  /* ====================================================== */
  /* ================= LESSON COMPLETE ==================== */
  /* ====================================================== */

  const toggleLesson = (lessonId) => {
    setLessons((prev) =>
      prev.map((lesson) =>
        lesson.id === lessonId
          ? {
              ...lesson,
              completed: !lesson.completed,
            }
          : lesson
      )
    );
  };

  /* ====================================================== */

  const completedLessons =
    lessons.filter((l) => l.completed).length;

  const completionPercentage =
    (completedLessons / lessons.length) * 100;

  /* ====================================================== */

  return (
    <div
      className="
        relative min-h-screen overflow-hidden
        bg-[#050816]
        px-6 pb-20 pt-24
        lg:px-10
      "
    >
      {/* Glow Effects */}

      <div
        className="
          absolute -left-24 top-0
          h-[350px] w-[350px]
          rounded-full
          bg-blue-500/20
          blur-[120px]
        "
      />

      <div
        className="
          absolute -right-24 bottom-0
          h-[350px] w-[350px]
          rounded-full
          bg-pink-500/20
          blur-[120px]
        "
      />

      <div className="relative z-10 mx-auto max-w-7xl">
        {/* ====================================================== */}
        {/* ================= HEADER ============================= */}
        {/* ====================================================== */}

        <div className="mb-12 grid gap-10 lg:grid-cols-[1.2fr_0.8fr]">
          {/* LEFT */}

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            {/* Badge */}

            <div
              className={`
                mb-5 inline-flex items-center gap-2
                rounded-full px-4 py-2
                ${glass}
              `}
            >
              <Sparkles
                size={16}
                className="text-cyan-400"
              />

              <span className="text-sm font-medium text-cyan-400">
                Live AI Mentor Session
              </span>
            </div>

            {/* Title */}

            <h1
              className="
                mb-5 text-4xl font-extrabold
                leading-tight tracking-tight
                md:text-5xl
              "
            >
              <span className="text-white">
                {course.mentor}
              </span>

              <br />

              <span
                className="
                  bg-gradient-to-r
                  from-cyan-400
                  via-blue-500
                  to-purple-500
                  bg-clip-text
                  text-transparent
                "
              >
                AI Session
              </span>
            </h1>

            {/* Description */}

            <p
              className="
                max-w-3xl text-base
                leading-8 text-slate-400
                md:text-lg
              "
            >
              Interact with {course.mentor} AI in
              real-time. Ask questions, receive
              personalized guidance, and master
              Artificial Intelligence.
            </p>

            {/* Mentor Card */}

            <div
              className="
                mt-8 flex items-center gap-4
                rounded-3xl border border-white/10
                bg-white/5 p-5
                backdrop-blur-xl
                max-w-xl
              "
            >
              <img
                src={course.image}
                alt={course.mentor}
                className="
                  h-16 w-16 rounded-full
                  border-2 border-cyan-400/40
                  object-cover
                "
              />

              <div>
                <h3 className="text-lg font-bold text-white">
                  {course.mentor} AI
                </h3>

                <p className="text-sm text-slate-400">
                  {course.role}
                </p>

                <div className="mt-2 flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-green-400" />

                  <span className="text-xs text-green-400">
                    Live & Ready To Teach
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* RIGHT */}

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7 }}
          >
            <div
              className={`
                rounded-3xl p-8
                ${glass}
              `}
            >
              <div className="mb-6 flex items-center gap-4">
                <div
                  className="
                    flex h-16 w-16
                    items-center justify-center
                    rounded-2xl
                    bg-gradient-to-r
                    from-blue-500
                    to-purple-600
                  "
                >
                  <BrainCircuit
                    size={30}
                    className="text-white"
                  />
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-white">
                    AI Mentor Mode
                  </h3>

                  <p className="text-slate-400">
                    Personalized adaptive learning
                  </p>
                </div>
              </div>

              {/* Progress */}

              <div className="mb-6">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm text-slate-400">
                    Course Progress
                  </span>

                  <span className="text-sm text-cyan-400">
                    {Math.round(completionPercentage)}%
                  </span>
                </div>

                <div className="h-3 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="
                      h-full rounded-full
                      bg-gradient-to-r
                      from-cyan-400
                      to-blue-500
                      transition-all duration-500
                    "
                    style={{
                      width: `${completionPercentage}%`,
                    }}
                  />
                </div>
              </div>

              {/* Features */}

              <div className="space-y-4">
                <div
                  className="
                    flex items-center gap-3
                    rounded-2xl
                    border border-white/10
                    bg-white/5 p-4
                  "
                >
                  <Mic
                    size={20}
                    className="text-cyan-400"
                  />

                  <span className="text-white">
                    Voice Interaction Enabled
                  </span>
                </div>

                <div
                  className="
                    flex items-center gap-3
                    rounded-2xl
                    border border-white/10
                    bg-white/5 p-4
                  "
                >
                  <MessageSquare
                    size={20}
                    className="text-pink-400"
                  />

                  <span className="text-white">
                    Real-Time AI Chat Support
                  </span>
                </div>

                <div
                  className="
                    flex items-center gap-3
                    rounded-2xl
                    border border-white/10
                    bg-white/5 p-4
                  "
                >
                  <BookOpen
                    size={20}
                    className="text-yellow-400"
                  />

                  <span className="text-white">
                    Personalized Lessons
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* ====================================================== */}
        {/* ================= VIDEO SECTION ====================== */}
        {/* ====================================================== */}

        <div className="grid gap-10 lg:grid-cols-[1fr_0.35fr]">
          {/* Video */}

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7 }}
          >
            <div
              className={`
                overflow-hidden rounded-3xl
                ${glass}
              `}
            >
              {/* Video */}

              <video
                ref={videoRef}
                src={course.video}
                className="
                  aspect-video w-full
                  bg-black object-cover
                "
                onTimeUpdate={handleTimeUpdate}
              />

              {/* Controls */}

              <div className="space-y-4 p-5">
                {/* Progress */}

                <div className="h-2 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="
                      h-full rounded-full
                      bg-gradient-to-r
                      from-cyan-400
                      to-blue-500
                    "
                    style={{
                      width: `${progress}%`,
                    }}
                  />
                </div>

                {/* Buttons */}

                <div className="flex items-center justify-between">
                  <button
                    onClick={togglePlay}
                    className="
                      flex items-center gap-2
                      rounded-xl
                      bg-gradient-to-r
                      from-blue-500
                      to-purple-600
                      px-5 py-3
                      font-medium text-white
                      transition hover:scale-105
                    "
                  >
                    {isPlaying ? (
                      <>
                        <PauseCircle size={22} />
                        Pause
                      </>
                    ) : (
                      <>
                        <PlayCircle size={22} />
                        Play
                      </>
                    )}
                  </button>

                  {/* Volume */}

                  <div className="flex items-center gap-3">
                    <Volume2
                      className="text-white"
                      size={18}
                    />

                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={volume}
                      onChange={handleVolume}
                      className="w-28"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Notes */}

            <div
              className={`
                mt-8 rounded-3xl p-8
                ${glass}
              `}
            >
              <h2 className="mb-5 text-2xl font-bold text-white">
                AI Mentor Insights
              </h2>

              <p className="leading-8 text-slate-400">
                Your AI mentor adapts explanations,
                simplifies difficult concepts, and
                provides personalized learning guidance
                based on your understanding.
              </p>
            </div>
          </motion.div>

          {/* Sidebar */}

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div
              className={`
                rounded-3xl p-6
                ${glass}
              `}
            >
              <h2 className="mb-6 text-2xl font-bold text-white">
                Learning Path
              </h2>

              <div className="space-y-4">
                {lessons.map((lesson, index) => (
                  <div
                    key={lesson.id}
                    className="
                      rounded-2xl
                      border border-white/10
                      bg-white/5 p-4
                    "
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className="
                          mt-1 flex h-8 w-8
                          items-center justify-center
                          rounded-full
                          bg-blue-500/10
                          text-sm font-semibold
                          text-cyan-400
                        "
                      >
                        {index + 1}
                      </div>

                      <div className="flex-1">
                        <h3 className="font-medium text-white">
                          {lesson.title}
                        </h3>

                        <button
                          onClick={() =>
                            toggleLesson(lesson.id)
                          }
                          className={`
                            mt-3 flex items-center gap-2
                            rounded-xl px-4 py-2
                            text-sm font-medium
                            transition-all

                            ${
                              lesson.completed
                                ? "bg-green-500/20 text-green-400"
                                : "bg-white/10 text-slate-300"
                            }
                          `}
                        >
                          <CheckCircle2 size={16} />

                          {lesson.completed
                            ? "Completed"
                            : "Mark Complete"}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* CTA */}

              <button
                className="
                  mt-8 flex w-full items-center
                  justify-center gap-2
                  rounded-2xl
                  bg-gradient-to-r
                  from-blue-500
                  to-purple-600
                  px-6 py-4
                  text-sm font-semibold text-white
                  transition-all duration-300
                  hover:scale-[1.02]
                "
              >
                Start Mentor Conversation

                <ArrowRight size={18} />
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default WatchCourse;