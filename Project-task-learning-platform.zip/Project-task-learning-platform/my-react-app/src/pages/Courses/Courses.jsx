import CourseGrid from "../../components/Course/CourseGrid";

import { Sparkles, Users, Brain, Trophy } from "lucide-react";

import allMentors from "../../data/allMentors";

function Courses() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050816] pt-24">
      {/* BACKGROUND GLOWS */}

      <div className="absolute -left-24 top-0 h-[350px] w-[350px] rounded-full bg-blue-500/20 blur-[120px]" />

      <div className="absolute -right-24 top-40 h-[350px] w-[350px] rounded-full bg-pink-500/20 blur-[120px]" />

      <div className="absolute bottom-0 left-1/3 h-[300px] w-[300px] rounded-full bg-cyan-500/10 blur-[120px]" />

      {/* HERO */}

      <div className="relative z-10 px-6 lg:px-10">
        <div className="mx-auto max-w-7xl">
          <div
            className="
              rounded-3xl
              border border-white/10
              bg-white/5
              px-8 py-14
              backdrop-blur-xl
              md:px-12 md:py-16
            "
          >
            {/* BADGE */}

            <div
              className="
                mb-5 inline-flex items-center gap-2
                rounded-full border border-white/10
                bg-white/5 px-4 py-2
                backdrop-blur-xl
              "
            >
              <Sparkles
                size={16}
                className="text-cyan-400"
              />

              <span className="text-sm font-medium text-cyan-400">
                AI Celebrity Mentors
              </span>
            </div>

            {/* HEADING */}

            <h1
              className="
                mb-5 text-4xl font-extrabold
                leading-tight tracking-tight
                md:text-5xl lg:text-6xl
              "
            >
              <span className="text-white">
                Learn Directly From
              </span>

              <br />

              <span
                className="
                  bg-gradient-to-r
                  from-cyan-400
                  via-blue-500
                  to-purple-500
                  bg-clip-text
                  text-transparent
                "
              >
                Legendary AI Mentors
              </span>
            </h1>

            {/* DESCRIPTION */}

            <p
              className="
                max-w-3xl
                text-base leading-8
                text-slate-400
                md:text-lg
              "
            >
              Explore futuristic learning
              experiences powered by elite
              mentors, celebrity personalities,
              entrepreneurs, athletes, scientists,
              and innovators. Unlock immersive AI
              sessions, voice-guided mentorship,
              real-world skill systems, and
              next-generation learning journeys.
            </p>

            {/* STATS */}

            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {/* TOTAL MENTORS */}

              <div
                className="
                  rounded-2xl border border-white/10
                  bg-white/5 p-5
                "
              >
                <Users className="mb-3 text-cyan-400" />

                <h3 className="text-3xl font-black text-white">
                  {allMentors.length}+
                </h3>

                <p className="mt-1 text-sm text-slate-400">
                  AI Celebrity Mentors
                </p>
              </div>

              {/* COURSES */}

              <div
                className="
                  rounded-2xl border border-white/10
                  bg-white/5 p-5
                "
              >
                <Brain className="mb-3 text-pink-400" />

                <h3 className="text-3xl font-black text-white">
                  100+
                </h3>

                <p className="mt-1 text-sm text-slate-400">
                  Interactive Sessions
                </p>
              </div>

              {/* COMPLETION */}

              <div
                className="
                  rounded-2xl border border-white/10
                  bg-white/5 p-5
                "
              >
                <Trophy className="mb-3 text-yellow-400" />

                <h3 className="text-3xl font-black text-white">
                  98%
                </h3>

                <p className="mt-1 text-sm text-slate-400">
                  Completion Success
                </p>
              </div>

              {/* EXPERIENCE */}

              <div
                className="
                  rounded-2xl border border-white/10
                  bg-white/5 p-5
                "
              >
                <Sparkles className="mb-3 text-purple-400" />

                <h3 className="text-3xl font-black text-white">
                  AI
                </h3>

                <p className="mt-1 text-sm text-slate-400">
                  Personalized Learning
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION TITLE */}

      <div className="relative z-10 mt-16 px-6 lg:px-10">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-black text-white">
                Explore Mentors
              </h2>

              <p className="mt-2 text-slate-400">
                Choose your AI-powered mentor
                and start mastering elite skills.
              </p>
            </div>

            <div
              className="
                hidden rounded-2xl
                border border-cyan-500/20
                bg-cyan-500/10
                px-5 py-3
                lg:block
              "
            >
              <span className="text-cyan-400">
                {allMentors.length} mentors available
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* COURSE GRID */}

      <div className="relative z-10 pb-20">
        <CourseGrid />
      </div>
    </div>
  );
}

export default Courses;