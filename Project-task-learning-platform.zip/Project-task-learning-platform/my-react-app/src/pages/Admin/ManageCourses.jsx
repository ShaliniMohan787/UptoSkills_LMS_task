import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Users,
  IndianRupee,
  Sparkles,
  BookOpen,
  X,
} from "lucide-react";

import { motion } from "framer-motion";

import { useEffect, useState } from "react";

import allMentorsData from "../../data/allMentors";

const glass =
  "rounded-[32px] border border-white/10 bg-white/5 backdrop-blur-xl";

const actionButton =
  "flex h-12 w-12 items-center justify-center rounded-2xl transition-all hover:scale-110";

const tableHead =
  "p-6 text-left text-slate-400";

function ManageCourses() {
  /* COURSES */

  const [courses, setCourses] =
    useState([]);

  /* SEARCH */

  const [search, setSearch] =
    useState("");

  /* MODAL */

  const [showModal, setShowModal] =
    useState(false);

  /* EDITING */

  const [editingCourse, setEditingCourse] =
    useState(null);

  /* FORM */

  const [formData, setFormData] =
    useState({
      mentor: "",

      course: "",

      category: "",

      price: "",

      status: "Published",
    });

  /* LOAD COURSES */

  useEffect(() => {
    const saved =
      JSON.parse(
        localStorage.getItem(
          "manageCourses"
        )
      ) || allMentorsData;

    setCourses(saved);
  }, []);

  /* SAVE COURSES */

  useEffect(() => {
    localStorage.setItem(
      "manageCourses",
      JSON.stringify(courses)
    );
  }, [courses]);

  /* ADD COURSE */

  const handleAddCourse = () => {
    const newCourse = {
      id: Date.now(),

      mentor: formData.mentor,

      course: formData.course,

      category: formData.category,

      price: formData.price,

      status: formData.status,

      students: "0",

      image:
        "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    };

    setCourses([
      ...courses,
      newCourse,
    ]);

    resetForm();
  };

  /* DELETE */

  const handleDelete = (id) => {
    const updated =
      courses.filter(
        (course) => course.id !== id
      );

    setCourses(updated);
  };

  /* EDIT */

  const handleEdit = (course) => {
    setEditingCourse(course);

    setFormData({
      mentor: course.mentor,

      course: course.course,

      category: course.category,

      price: course.price,

      status: course.status,
    });

    setShowModal(true);
  };

  /* UPDATE */

  const handleUpdateCourse = () => {
    const updatedCourses =
      courses.map((course) =>
        course.id === editingCourse.id
          ? {
              ...course,

              mentor:
                formData.mentor,

              course:
                formData.course,

              category:
                formData.category,

              price:
                formData.price,

              status:
                formData.status,
            }
          : course
      );

    setCourses(updatedCourses);

    resetForm();
  };

  /* RESET */

  const resetForm = () => {
    setFormData({
      mentor: "",

      course: "",

      category: "",

      price: "",

      status: "Published",
    });

    setEditingCourse(null);

    setShowModal(false);
  };

  /* SEARCH FILTER */

  const filteredCourses =
    courses.filter((course) =>
      `${course.mentor} ${course.course}`
        .toLowerCase()
        .includes(search.toLowerCase())
    );

  /* OVERVIEW */

  const overviewCards = [
    {
      title: "Total Courses",

      value: courses.length,

      icon: BookOpen,

      bg: "bg-blue-500/10",

      text: "text-cyan-400",
    },

    {
      title: "Total Students",

      value: "52K+",

      icon: Users,

      bg: "bg-pink-500/10",

      text: "text-pink-400",
    },

    {
      title: "Revenue",

      value: "₹24L",

      icon: IndianRupee,

      bg: "bg-green-500/10",

      text: "text-green-400",
    },
  ];

  return (
    <div className="min-h-screen bg-[#050816] px-6 py-10 lg:px-10">
      {/* HEADER */}

      <div className="mb-14 flex flex-col justify-between gap-8 xl:flex-row xl:items-center">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 backdrop-blur-xl">
            <Sparkles
              size={18}
              className="text-cyan-400"
            />

            <span className="font-medium text-cyan-400">
              UpToSkills Course Control
            </span>
          </div>

          <h1 className="mb-5 text-5xl font-extrabold leading-tight tracking-tight md:text-6xl">
            <span className="text-white">
              Manage
            </span>

            <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
              {" "}
              Courses
            </span>
          </h1>

          <p className="max-w-3xl text-lg leading-8 text-slate-400">
            Add, update, and organize
            celebrity mentor learning
            experiences from your admin
            control center.
          </p>
        </div>

        {/* ADD BUTTON */}

        <button
          onClick={() =>
            setShowModal(true)
          }
          className="
            flex items-center gap-3
            rounded-2xl
            bg-gradient-to-r
            from-blue-500 to-purple-600
            px-8 py-4
            font-semibold text-white
            shadow-[0_0_40px_rgba(59,130,246,0.35)]
            transition-all duration-300
            hover:scale-105
          "
        >
          <Plus size={20} />
          Add Course
        </button>
      </div>

      {/* OVERVIEW */}

      <div className="mb-14 grid gap-8 md:grid-cols-3">
        {overviewCards.map((item) => {
          const Icon = item.icon;

          return (
            <motion.div
              key={item.title}
              whileHover={{ y: -5 }}
              className={`${glass} p-8`}
            >
              <div
                className={`mb-8 flex h-16 w-16 items-center justify-center rounded-2xl ${item.bg}`}
              >
                <Icon
                  size={28}
                  className={item.text}
                />
              </div>

              <p className="mb-3 text-slate-400">
                {item.title}
              </p>

              <h2 className="text-4xl font-extrabold text-white">
                {item.value}
              </h2>
            </motion.div>
          );
        })}
      </div>

      {/* TABLE */}

      <div className={`${glass} overflow-hidden`}>
        {/* TOP */}

        <div className="flex flex-col justify-between gap-6 border-b border-white/10 p-8 lg:flex-row lg:items-center">
          <div>
            <h3 className="mb-2 text-3xl font-bold text-white">
              Course Library
            </h3>

            <p className="text-slate-400">
              Manage mentor programs
            </p>
          </div>

          {/* SEARCH */}

          <div className="flex w-full items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 lg:w-[420px]">
            <Search
              size={20}
              className="text-slate-400"
            />

            <input
              type="text"
              placeholder="Search courses..."
              value={search}
              onChange={(e) =>
                setSearch(
                  e.target.value
                )
              }
              className="w-full bg-transparent text-white outline-none placeholder:text-slate-500"
            />
          </div>
        </div>

        {/* TABLE */}

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                {[
                  "Mentor",
                  "Course",
                  "Category",
                  "Price",
                  "Status",
                  "Actions",
                ].map((head) => (
                  <th
                    key={head}
                    className={tableHead}
                  >
                    {head}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {filteredCourses.map(
                (course) => (
                  <tr
                    key={course.id}
                    className="border-b border-white/5 transition hover:bg-white/5"
                  >
                    <td className="p-6 font-semibold text-white">
                      {course.mentor}
                    </td>

                    <td className="p-6 text-slate-300">
                      {course.course}
                    </td>

                    <td className="p-6 text-cyan-400">
                      {course.category}
                    </td>

                    <td className="p-6 text-green-400">
                      {course.price}
                    </td>

                    <td className="p-6">
                      <span
                        className={`
                          rounded-full px-4 py-2 text-sm font-medium
                          ${
                            course.status ===
                            "Published"
                              ? "border border-green-500/20 bg-green-500/10 text-green-400"
                              : "border border-yellow-500/20 bg-yellow-500/10 text-yellow-400"
                          }
                        `}
                      >
                        {course.status}
                      </span>
                    </td>

                    {/* ACTIONS */}

                    <td className="p-6">
                      <div className="flex items-center gap-4">
                        {/* EDIT */}

                        <button
                          onClick={() =>
                            handleEdit(
                              course
                            )
                          }
                          className={`${actionButton} border border-blue-500/20 bg-blue-500/10`}
                        >
                          <Pencil
                            size={18}
                            className="text-cyan-400"
                          />
                        </button>

                        {/* DELETE */}

                        <button
                          onClick={() =>
                            handleDelete(
                              course.id
                            )
                          }
                          className={`${actionButton} border border-red-500/20 bg-red-500/10`}
                        >
                          <Trash2
                            size={18}
                            className="text-red-400"
                          />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL */}

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div
            className={`${glass} w-full max-w-xl p-8`}
          >
            <div className="mb-8 flex items-center justify-between">
              <h2 className="text-3xl font-bold text-white">
                {editingCourse
                  ? "Edit Course"
                  : "Add Course"}
              </h2>

              <button
                onClick={resetForm}
              >
                <X className="text-white" />
              </button>
            </div>

            <div className="space-y-5">
              <input
                type="text"
                placeholder="Mentor Name"
                value={formData.mentor}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    mentor:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <input
                type="text"
                placeholder="Course Name"
                value={formData.course}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    course:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <input
                type="text"
                placeholder="Category"
                value={formData.category}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    category:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <input
                type="text"
                placeholder="Price"
                value={formData.price}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    price:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    status:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-[#111827] p-4 text-white outline-none"
              >
                <option>
                  Published
                </option>

                <option>
                  Draft
                </option>
              </select>

              {/* BUTTON */}

              <button
                onClick={
                  editingCourse
                    ? handleUpdateCourse
                    : handleAddCourse
                }
                className="
                  mt-4 w-full rounded-2xl
                  bg-gradient-to-r
                  from-blue-500 to-purple-600
                  py-4 font-semibold text-white
                "
              >
                {editingCourse
                  ? "Update Course"
                  : "Add Course"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ManageCourses;