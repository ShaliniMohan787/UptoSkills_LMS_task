import {
  Users,
  BookOpen,
  IndianRupee,
  GraduationCap,
  ArrowUpRight,
  Activity,
  BrainCircuit,
  Sparkles,
  Trophy,
  Clock3,
  CheckCircle2,
} from "lucide-react";
import jsPDF from "jspdf";

import autoTable from "jspdf-autotable";
import { motion } from "framer-motion";

import {
  useEffect,
  useState,
} from "react";

/* IMPORT COURSES */
import allMentors from "../../data/allMentors";

const glassCard =
  "rounded-[32px] border border-white/10 bg-white/5 backdrop-blur-xl";

const sectionTitle =
  "text-2xl md:text-3xl font-bold text-white";

function AdminDashboard() {
  const [stats, setStats] =
    useState([]);

  const [activities, setActivities] =
    useState([]);
  const generateReport = () => {
  const doc = new jsPDF();

  /* TITLE */
  doc.setFontSize(24);

  doc.text(
    "UpToSkills Admin Report",
    20,
    20
  );

  /* DATE */
  doc.setFontSize(12);

  doc.text(
    `Generated: ${new Date().toLocaleString()}`,
    20,
    30
  );

  /* STATS TABLE */
  autoTable(doc, {
    startY: 45,

    head: [["Metric", "Value"]],

    body: stats.map((item) => [
      item.title,
      item.value,
    ]),
  });

  /* ACTIVITIES */
  doc.setFontSize(18);

  doc.text(
    "Recent Activity",
    20,
    doc.lastAutoTable.finalY + 20
  );

  let y =
    doc.lastAutoTable.finalY + 35;

  activities.forEach((activity) => {
    doc.setFontSize(12);

    doc.text(`• ${activity}`, 25, y);

    y += 10;
  });

  /* SAVE */
  doc.save(
    `UpToSkills-Report-${Date.now()}.pdf`
  );
};
  useEffect(() => {
    /* FIX ARRAY / OBJECT ISSUE */
    const mentorsArray =
      Array.isArray(allMentors)
        ? allMentors
        : Object.keys(allMentors).map(
            (key) => ({
              id: Number(key),
              ...allMentors[key],
            })
          );

    /* ENROLLED COURSES */
    const enrolledCourses =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    /* TOTAL MODULES COMPLETED */
    let completedModules = 0;

    mentorsArray.forEach((course) => {
      const progress =
        JSON.parse(
          localStorage.getItem(
            `course-progress-${course.id}`
          )
        ) || [];

      completedModules +=
        progress.length;
    });

    /* COMPLETED COURSES */
    const completedCourses =
      mentorsArray.filter((course) => {
        const progress =
          JSON.parse(
            localStorage.getItem(
              `course-progress-${course.id}`
            )
          ) || [];

        const modules =
          course.modules || [];

        return (
          modules.length > 0 &&
          progress.length ===
            modules.length
        );
      });

    /* REVENUE */
    const revenue =
      enrolledCourses.length * 4999;

    /* STATS */
    setStats([
      {
        title: "Total Students",

        value: "52,489",

        icon: Users,

        color:
          "from-cyan-400 to-blue-500",
      },

      {
        title: "Active Courses",

        value:
          mentorsArray.length.toString(),

        icon: BookOpen,

        color:
          "from-pink-500 to-orange-400",
      },

      {
        title: "Revenue",

        value: `₹${(
          revenue / 100000
        ).toFixed(1)}L`,

        icon: IndianRupee,

        color:
          "from-green-400 to-emerald-500",
      },

      {
        title: "Instructors",

        value:
          mentorsArray.length.toString(),

        icon: GraduationCap,

        color:
          "from-purple-500 to-indigo-500",
      },
    ]);

    /* ACTIVITIES */
    setActivities([
      `${mentorsArray.length} AI mentor courses active`,

      `${enrolledCourses.length} total enrollments`,

      `${completedCourses.length} courses completed`,

      `${completedModules} modules completed by learners`,

      `Revenue reached ₹${revenue.toLocaleString()}`,

      "AI learning analytics updated",
    ]);
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050816] px-6 py-10 lg:px-10">
      {/* GLOW EFFECTS */}
      <div className="absolute -left-32 top-0 h-[450px] w-[450px] rounded-full bg-cyan-500/10 blur-[140px]" />

      <div className="absolute -right-32 bottom-0 h-[450px] w-[450px] rounded-full bg-purple-500/10 blur-[140px]" />

      {/* MAIN */}
      <div className="relative z-10">
        {/* HEADER */}
        <div className="mb-14 flex flex-col justify-between gap-8 lg:flex-row lg:items-center">
          {/* LEFT */}
          <div>
            {/* BADGE */}
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 backdrop-blur-xl">
              <Activity
                size={18}
                className="text-cyan-400"
              />

              <span className="font-medium text-cyan-400">
                Platform Analytics
              </span>
            </div>

            {/* TITLE */}
            <h1 className="mb-4 text-5xl font-extrabold leading-tight tracking-tight md:text-6xl">
              <span className="text-white">
                Admin
              </span>

              <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
                {" "}
                Dashboard
              </span>
            </h1>

            {/* DESCRIPTION */}
            <p className="max-w-2xl text-lg leading-8 text-slate-400">
              Monitor platform growth,
              student engagement,
              mentor performance,
              enrollments, and futuristic
              AI learning analytics from
              a centralized control hub.
            </p>
          </div>

          {/* BUTTON */}
         
          <button
  onClick={generateReport}
  className="
    flex items-center gap-3
    rounded-2xl
    bg-gradient-to-r
    from-blue-500 to-purple-600
    px-8 py-4
    font-semibold text-white
    shadow-[0_0_40px_rgba(59,130,246,0.35)]
    transition-all duration-300
    hover:scale-105
  "
>  Generate Report

            <ArrowUpRight size={20} />
          </button>
        </div>

        {/* STATS */}
        <div className="mb-14 grid gap-8 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((item, index) => {
            const Icon = item.icon;

            return (
              <motion.div
                key={item.title}
                initial={{
                  opacity: 0,
                  y: 40,
                }}
                animate={{
                  opacity: 1,
                  y: 0,
                }}
                transition={{
                  delay:
                    index * 0.1,
                }}
                className={`${glassCard} relative overflow-hidden p-8 transition-all duration-500 hover:-translate-y-2`}
              >
                {/* GLOW */}
                <div
                  className={`
                    absolute right-0 top-0
                    h-40 w-40 rounded-full
                    bg-gradient-to-br
                    ${item.color}
                    opacity-10 blur-[80px]
                  `}
                />

                {/* ICON */}
                <div
                  className={`
                    mb-8 flex h-16 w-16
                    items-center justify-center
                    rounded-2xl
                    bg-gradient-to-r
                    ${item.color}
                  `}
                >
                  <Icon size={30} />
                </div>

                {/* CONTENT */}
                <p className="mb-3 text-slate-400">
                  {item.title}
                </p>

                <h2 className="mb-5 text-4xl font-extrabold text-white md:text-5xl">
                  {item.value}
                </h2>
              </motion.div>
            );
          })}
        </div>

        {/* EXTRA STATS */}
        <div className="mb-14 grid gap-8 md:grid-cols-3">
          {/* CERTIFICATIONS */}
          <div className={`${glassCard} p-8`}>
            <div className="mb-5 flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-yellow-500/10">
                <Trophy className="text-yellow-400" />
              </div>

              <div>
                <p className="text-slate-400">
                  Certifications
                </p>

                <h3 className="text-3xl font-bold text-white">
                  2,450
                </h3>
              </div>
            </div>
          </div>

          {/* AI SCORE */}
          <div className={`${glassCard} p-8`}>
            <div className="mb-5 flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-pink-500/10">
                <BrainCircuit className="text-pink-400" />
              </div>

              <div>
                <p className="text-slate-400">
                  AI Skill Growth
                </p>

                <h3 className="text-3xl font-bold text-white">
                  94%
                </h3>
              </div>
            </div>
          </div>

          {/* SESSION */}
          <div className={`${glassCard} p-8`}>
            <div className="mb-5 flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-500/10">
                <Clock3 className="text-cyan-400" />
              </div>

              <div>
                <p className="text-slate-400">
                  Avg Session Time
                </p>

                <h3 className="text-3xl font-bold text-white">
                  4.8 hrs
                </h3>
              </div>
            </div>
          </div>
        </div>

        {/* RECENT ACTIVITY */}
        <div className={`${glassCard} p-8`}>
          <div className="mb-8 flex items-center gap-3">
            <Sparkles className="text-cyan-400" />

            <h3 className={sectionTitle}>
              Recent Activity
            </h3>
          </div>

          <div className="space-y-6">
            {activities.map(
              (item, index) => (
                <motion.div
                  key={index}
                  initial={{
                    opacity: 0,
                    x: 20,
                  }}
                  animate={{
                    opacity: 1,
                    x: 0,
                  }}
                  transition={{
                    delay:
                      index * 0.1,
                  }}
                  className="
                    flex items-start gap-4
                    rounded-2xl
                    border border-white/5
                    bg-white/5 p-5
                  "
                >
                  <div className="mt-2 h-3 w-3 rounded-full bg-cyan-400" />

                  <p className="leading-7 text-slate-300">
                    {item}
                  </p>
                </motion.div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;