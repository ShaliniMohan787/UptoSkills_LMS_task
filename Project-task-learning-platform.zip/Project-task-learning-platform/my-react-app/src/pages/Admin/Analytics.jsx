import {
  TrendingUp,
  Users,
  IndianRupee,
  Activity,
  ArrowUpRight,
  BarChart3,
  PieChart,
  BrainCircuit,
  Trophy,
} from "lucide-react";

import { motion } from "framer-motion";

import jsPDF from "jspdf";

import autoTable from "jspdf-autotable";

import allMentors from "../../data/allMentors";

const enrolledCourses =
  JSON.parse(
    localStorage.getItem("enrolledCourses")
  ) || [];

const analyticsStats = [
  {
    title: "Enrolled Students",
    value: `${enrolledCourses.length * 124 + 1200}`,

    growth: "+18.1%",

    icon: Users,

    color: "from-cyan-400 to-blue-500",
  },

  {
    title: "Platform Revenue",

    value: `₹${(
      enrolledCourses.length * 4999
    ).toLocaleString()}`,

    growth: "+22.4%",

    icon: IndianRupee,

    color: "from-green-400 to-emerald-500",
  },

  {
    title: "Course Completion",

    value: "84%",

    growth: "+9.2%",

    icon: Activity,

    color: "from-orange-400 to-pink-500",
  },

  {
    title: "AI Engagement",

    value: "92%",

    growth: "+12.6%",

    icon: BrainCircuit,

    color: "from-purple-500 to-indigo-500",
  },
];

const chartData = [45, 65, 55, 80, 70, 95, 85];

const glass =
  "rounded-[32px] border border-white/10 bg-white/5 backdrop-blur-xl";

const sectionTitle =
  "text-2xl md:text-3xl font-bold text-white";

/* PDF REPORT */

const generateReport = () => {
  const doc = new jsPDF();

  doc.setFontSize(24);

  doc.text(
    "UpToSkills Analytics Report",
    20,
    20
  );

  doc.setFontSize(12);

  doc.text(
    `Generated: ${new Date().toLocaleString()}`,
    20,
    30
  );

  autoTable(doc, {
    startY: 45,

    head: [["Metric", "Value"]],

    body: analyticsStats.map((item) => [
      item.title,
      item.value,
    ]),
  });

  doc.text(
    "Top Mentor Courses",
    20,
    doc.lastAutoTable.finalY + 20
  );

  autoTable(doc, {
    startY: doc.lastAutoTable.finalY + 30,

    head: [
      [
        "Mentor",
        "Course",
        "Category",
      ],
    ],

    body: enrolledCourses.map((courseId) => {
      const course = allMentors.find(
        (m) => m.id === courseId
      );

      return [
        course?.mentor,
        course?.course,
        course?.category,
      ];
    }),
  });

  doc.save("UpToSkills-Analytics.pdf");
};

function StatCard({ item, index }) {
  const Icon = item.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className={`${glass} relative overflow-hidden p-8 transition-all duration-500 hover:-translate-y-2`}
    >
      <div
        className={`
          absolute right-0 top-0 h-40 w-40
          rounded-full bg-gradient-to-br
          ${item.color}
          opacity-10 blur-[80px]
        `}
      />

      <div
        className={`
          mb-8 flex h-16 w-16
          items-center justify-center
          rounded-2xl bg-gradient-to-r
          ${item.color}
        `}
      >
        <Icon size={30} />
      </div>

      <p className="mb-3 text-slate-400">
        {item.title}
      </p>

      <h2 className="mb-5 text-4xl font-extrabold text-white md:text-5xl">
        {item.value}
      </h2>

      <div className="inline-flex items-center gap-2 rounded-full border border-green-500/20 bg-green-500/10 px-4 py-2 text-sm font-medium text-green-400">
        <TrendingUp size={16} />

        {item.growth}
      </div>
    </motion.div>
  );
}

function Analytics() {
  return (
    <div className="min-h-screen bg-[#050816] px-6 py-10 lg:px-10">
      {/* HEADER */}

      <div className="mb-16 flex flex-col justify-between gap-8 lg:flex-row lg:items-center">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 backdrop-blur-xl">
            <TrendingUp
              size={18}
              className="text-cyan-400"
            />

            <span className="font-medium text-cyan-400">
              UpToSkills Analytics
            </span>
          </div>

          <h1 className="mb-5 text-5xl font-extrabold leading-tight tracking-tight md:text-6xl">
            <span className="text-white">
              Analytics
            </span>

            <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
              {" "}
              Dashboard
            </span>
          </h1>

          <p className="max-w-3xl text-lg leading-8 text-slate-400">
            Monitor mentor engagement,
            learner growth, revenue
            trends, and platform activity
            in real-time.
          </p>
        </div>

        {/* BUTTON */}

        <button
          onClick={generateReport}
          className="
            flex items-center gap-3
            rounded-2xl
            bg-gradient-to-r
            from-blue-500 to-purple-600
            px-8 py-4
            font-semibold text-white
            shadow-[0_0_40px_rgba(59,130,246,0.35)]
            transition-all duration-300
            hover:scale-105
          "
        >
          Export Report

          <ArrowUpRight size={20} />
        </button>
      </div>

      {/* STATS */}

      <div className="mb-16 grid gap-8 md:grid-cols-2 xl:grid-cols-4">
        {analyticsStats.map(
          (item, index) => (
            <StatCard
              key={item.title}
              item={item}
              index={index}
            />
          )
        )}
      </div>

      {/* CHARTS */}

      <div className="mb-16 grid gap-8 xl:grid-cols-3">
        {/* GRAPH */}

        <div
          className={`${glass} xl:col-span-2 p-8`}
        >
          <div className="mb-10 flex items-center justify-between">
            <div>
              <h3 className={sectionTitle}>
                Revenue Growth
              </h3>

              <p className="text-slate-400">
                Monthly platform performance
              </p>
            </div>

            <BarChart3
              className="text-cyan-400"
              size={28}
            />
          </div>

          <div className="flex h-[380px] items-end gap-5 rounded-[28px] border border-white/10 bg-gradient-to-b from-blue-500/10 to-transparent p-8">
            {chartData.map(
              (height, index) => (
                <div
                  key={index}
                  className="
                    flex-1 rounded-t-2xl
                    bg-gradient-to-t
                    from-cyan-400 to-blue-500
                    transition-all duration-300
                    hover:scale-105
                  "
                  style={{
                    height: `${height}%`,
                  }}
                />
              )
            )}
          </div>
        </div>

        {/* ENGAGEMENT */}

        <div className={`${glass} p-8`}>
          <div className="mb-10 flex items-center justify-between">
            <div>
              <h3 className={sectionTitle}>
                Engagement
              </h3>

              <p className="text-slate-400">
                AI mentor interaction
              </p>
            </div>

            <PieChart
              className="text-pink-400"
              size={28}
            />
          </div>

          <div className="flex h-[380px] items-center justify-center">
            <div className="relative flex h-64 w-64 items-center justify-center rounded-full border-[18px] border-cyan-400 shadow-[0_0_40px_rgba(59,130,246,0.35)]">
              <div className="text-center">
                <h2 className="text-6xl font-extrabold text-white">
                  92%
                </h2>

                <p className="mt-3 text-slate-400">
                  Engagement Rate
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* TOP COURSES */}

      <div className={`${glass} p-8`}>
        <div className="mb-10 flex items-center justify-between">
          <div>
            <h3 className={sectionTitle}>
              Enrolled Mentor Courses
            </h3>

            <p className="text-slate-400">
              Most active celebrity mentor
              programs
            </p>
          </div>

          <Trophy className="text-yellow-400" />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                {[
                  "Mentor",
                  "Course",
                  "Category",
                ].map((head) => (
                  <th
                    key={head}
                    className="py-5 text-left text-slate-400"
                  >
                    {head}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {enrolledCourses.map(
                (courseId) => {
                  const course =
                    allMentors.find(
                      (m) =>
                        m.id === courseId
                    );

                  if (!course) return null;

                  return (
                    <tr
                      key={course.id}
                      className="
                        border-b border-white/5
                        transition hover:bg-white/5
                      "
                    >
                      <td className="py-6 font-medium text-white">
                        {course.mentor}
                      </td>

                      <td className="py-6 text-slate-300">
                        {course.course}
                      </td>

                      <td className="py-6 text-cyan-400">
                        {course.category}
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Analytics;