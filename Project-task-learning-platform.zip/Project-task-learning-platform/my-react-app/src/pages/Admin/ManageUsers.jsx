import {
  Users,
  Search,
  UserPlus,
  Mail,
  Shield,
  Trash2,
  Pencil,
  Activity,
  GraduationCap,
  Crown,
  Sparkles,
  X,
} from "lucide-react";

import { motion } from "framer-motion";

import { useEffect, useState } from "react";

const defaultUsers = [
  {
    id: 1,
    name: "Shalini Verma",
    email: "shalini@gmail.com",
    role: "Admin",
    status: "Active",
    enrolled: 12,
  },

  {
    id: 2,
    name: "Rahul Sharma",
    email: "rahul@gmail.com",
    role: "Student",
    status: "Active",
    enrolled: 5,
  },

  {
    id: 3,
    name: "Priya Nair",
    email: "priya@gmail.com",
    role: "Instructor",
    status: "Pending",
    enrolled: 18,
  },

  {
    id: 4,
    name: "Arjun Mehta",
    email: "arjun@gmail.com",
    role: "Student",
    status: "Active",
    enrolled: 7,
  },
];

const glass =
  "rounded-[32px] border border-white/10 bg-white/5 backdrop-blur-xl";

const actionButton =
  "flex h-12 w-12 items-center justify-center rounded-2xl transition-all hover:scale-110";

const tableHead =
  "p-6 text-left text-slate-400";

function StatCard({ item }) {
  const Icon = item.icon;

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className={`${glass} p-8`}
    >
      <div
        className={`mb-8 flex h-16 w-16 items-center justify-center rounded-2xl ${item.bg}`}
      >
        <Icon
          size={28}
          className={item.text}
        />
      </div>

      <p className="mb-3 text-slate-400">
        {item.title}
      </p>

      <h2 className="text-4xl font-extrabold text-white md:text-5xl">
        {item.value}
      </h2>
    </motion.div>
  );
}

function ManageUsers() {
  /* USERS */

  const [users, setUsers] =
    useState([]);

  /* SEARCH */

  const [search, setSearch] =
    useState("");

  /* MODAL */

  const [showModal, setShowModal] =
    useState(false);

  /* EDIT */

  const [editingUser, setEditingUser] =
    useState(null);

  /* FORM */

  const [formData, setFormData] =
    useState({
      name: "",

      email: "",

      role: "Student",

      status: "Active",

      enrolled: 0,
    });

  /* LOAD */

  useEffect(() => {
    const savedUsers =
      JSON.parse(
        localStorage.getItem(
          "manageUsers"
        )
      ) || defaultUsers;

    setUsers(savedUsers);
  }, []);

  /* SAVE */

  useEffect(() => {
    localStorage.setItem(
      "manageUsers",
      JSON.stringify(users)
    );
  }, [users]);

  /* ADD USER */

  const handleAddUser = () => {
    const newUser = {
      id: Date.now(),

      name: formData.name,

      email: formData.email,

      role: formData.role,

      status: formData.status,

      enrolled:
        Number(formData.enrolled),
    };

    setUsers([
      ...users,
      newUser,
    ]);

    resetForm();
  };

  /* DELETE */

  const handleDeleteUser = (id) => {
    const updated =
      users.filter(
        (user) => user.id !== id
      );

    setUsers(updated);
  };

  /* EDIT */

  const handleEditUser = (user) => {
    setEditingUser(user);

    setFormData({
      name: user.name,

      email: user.email,

      role: user.role,

      status: user.status,

      enrolled: user.enrolled,
    });

    setShowModal(true);
  };

  /* UPDATE */

  const handleUpdateUser = () => {
    const updatedUsers =
      users.map((user) =>
        user.id === editingUser.id
          ? {
              ...user,

              name:
                formData.name,

              email:
                formData.email,

              role:
                formData.role,

              status:
                formData.status,

              enrolled:
                Number(
                  formData.enrolled
                ),
            }
          : user
      );

    setUsers(updatedUsers);

    resetForm();
  };

  /* RESET */

  const resetForm = () => {
    setEditingUser(null);

    setShowModal(false);

    setFormData({
      name: "",

      email: "",

      role: "Student",

      status: "Active",

      enrolled: 0,
    });
  };

  /* FILTER */

  const filteredUsers =
    users.filter((user) =>
      `${user.name} ${user.email}`
        .toLowerCase()
        .includes(search.toLowerCase())
    );

  /* STATS */

  const stats = [
    {
      title: "Total Users",

      value: users.length,

      icon: Users,

      bg: "bg-blue-500/10",

      text: "text-cyan-400",
    },

    {
      title: "Instructors",

      value:
        users.filter(
          (user) =>
            user.role ===
            "Instructor"
        ).length,

      icon: GraduationCap,

      bg: "bg-pink-500/10",

      text: "text-pink-400",
    },

    {
      title: "Active Users",

      value:
        users.filter(
          (user) =>
            user.status ===
            "Active"
        ).length,

      icon: Activity,

      bg: "bg-green-500/10",

      text: "text-green-400",
    },
  ];

  return (
    <div className="min-h-screen bg-[#050816] px-6 py-10 lg:px-10">
      {/* HEADER */}

      <div className="mb-14 flex flex-col justify-between gap-8 xl:flex-row xl:items-center">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 backdrop-blur-xl">
            <Sparkles
              size={18}
              className="text-cyan-400"
            />

            <span className="font-medium text-cyan-400">
              User Administration
            </span>
          </div>

          <h1 className="mb-5 text-5xl font-extrabold leading-tight tracking-tight md:text-6xl">
            <span className="text-white">
              Manage
            </span>

            <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
              {" "}
              Users
            </span>
          </h1>

          <p className="max-w-3xl text-lg leading-8 text-slate-400">
            Control platform learners,
            instructors, and admins from
            your futuristic command hub.
          </p>
        </div>

        {/* ADD BUTTON */}

        <button
          onClick={() =>
            setShowModal(true)
          }
          className="
            flex items-center gap-3
            rounded-2xl
            bg-gradient-to-r
            from-blue-500 to-purple-600
            px-8 py-4
            font-semibold text-white
            shadow-[0_0_40px_rgba(59,130,246,0.35)]
            transition-all duration-300
            hover:scale-105
          "
        >
          <UserPlus size={20} />
          Add User
        </button>
      </div>

      {/* STATS */}

      <div className="mb-14 grid gap-8 md:grid-cols-3">
        {stats.map((item) => (
          <StatCard
            key={item.title}
            item={item}
          />
        ))}
      </div>

      {/* TABLE */}

      <div className={`${glass} overflow-hidden`}>
        {/* TOP */}

        <div className="flex flex-col justify-between gap-6 border-b border-white/10 p-8 lg:flex-row lg:items-center">
          <div>
            <h3 className="mb-2 text-3xl font-bold text-white">
              User Directory
            </h3>

            <p className="text-slate-400">
              Manage all platform users
            </p>
          </div>

          {/* SEARCH */}

          <div className="flex w-full items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 lg:w-[420px]">
            <Search
              size={20}
              className="text-slate-400"
            />

            <input
              type="text"
              placeholder="Search users..."
              value={search}
              onChange={(e) =>
                setSearch(
                  e.target.value
                )
              }
              className="w-full bg-transparent text-white outline-none placeholder:text-slate-500"
            />
          </div>
        </div>

        {/* TABLE */}

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                {[
                  "User",
                  "Email",
                  "Role",
                  "Courses",
                  "Status",
                  "Actions",
                ].map((head) => (
                  <th
                    key={head}
                    className={tableHead}
                  >
                    {head}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {filteredUsers.map(
                (user) => {
                  const isAdmin =
                    user.role ===
                    "Admin";

                  const isInstructor =
                    user.role ===
                    "Instructor";

                  return (
                    <tr
                      key={user.id}
                      className="border-b border-white/5 transition hover:bg-white/5"
                    >
                      {/* USER */}

                      <td className="p-6">
                        <div className="flex items-center gap-4">
                          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-r from-blue-500 to-purple-600 text-lg font-bold text-white">
                            {user.name.charAt(
                              0
                            )}
                          </div>

                          <div>
                            <h4 className="text-lg font-semibold text-white">
                              {
                                user.name
                              }
                            </h4>

                            <p className="text-slate-500">
                              User ID #
                              {user.id}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* EMAIL */}

                      <td className="p-6">
                        <div className="flex items-center gap-3 text-slate-300">
                          <Mail size={18} />
                          {
                            user.email
                          }
                        </div>
                      </td>

                      {/* ROLE */}

                      <td className="p-6">
                        <div
                          className={`
                            inline-flex items-center gap-2 rounded-full
                            px-4 py-2 text-sm font-medium
                            ${
                              isAdmin
                                ? "border border-purple-500/20 bg-purple-500/10 text-purple-400"
                                : isInstructor
                                ? "border border-pink-500/20 bg-pink-500/10 text-pink-400"
                                : "border border-blue-500/20 bg-blue-500/10 text-cyan-400"
                            }
                          `}
                        >
                          {isAdmin ? (
                            <Crown size={16} />
                          ) : (
                            <Shield size={16} />
                          )}

                          {user.role}
                        </div>
                      </td>

                      {/* ENROLLED */}

                      <td className="p-6 font-medium text-cyan-400">
                        {
                          user.enrolled
                        }
                      </td>

                      {/* STATUS */}

                      <td className="p-6">
                        <span
                          className={`
                            rounded-full px-4 py-2 text-sm font-medium
                            ${
                              user.status ===
                              "Active"
                                ? "border border-green-500/20 bg-green-500/10 text-green-400"
                                : "border border-yellow-500/20 bg-yellow-500/10 text-yellow-400"
                            }
                          `}
                        >
                          {user.status}
                        </span>
                      </td>

                      {/* ACTIONS */}

                      <td className="p-6">
                        <div className="flex items-center gap-4">
                          <button
                            onClick={() =>
                              handleEditUser(
                                user
                              )
                            }
                            className={`${actionButton} border border-blue-500/20 bg-blue-500/10`}
                          >
                            <Pencil
                              size={18}
                              className="text-cyan-400"
                            />
                          </button>

                          <button
                            onClick={() =>
                              handleDeleteUser(
                                user.id
                              )
                            }
                            className={`${actionButton} border border-red-500/20 bg-red-500/10`}
                          >
                            <Trash2
                              size={18}
                              className="text-red-400"
                            />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL */}

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div
            className={`${glass} w-full max-w-xl p-8`}
          >
            <div className="mb-8 flex items-center justify-between">
              <h2 className="text-3xl font-bold text-white">
                {editingUser
                  ? "Edit User"
                  : "Add User"}
              </h2>

              <button
                onClick={resetForm}
              >
                <X className="text-white" />
              </button>
            </div>

            <div className="space-y-5">
              <input
                type="text"
                placeholder="Full Name"
                value={formData.name}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    name:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <input
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    email:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <select
                value={formData.role}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    role:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-[#111827] p-4 text-white outline-none"
              >
                <option>
                  Student
                </option>

                <option>
                  Instructor
                </option>

                <option>
                  Admin
                </option>
              </select>

              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    status:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-[#111827] p-4 text-white outline-none"
              >
                <option>
                  Active
                </option>

                <option>
                  Pending
                </option>
              </select>

              <input
                type="number"
                placeholder="Enrolled Courses"
                value={
                  formData.enrolled
                }
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    enrolled:
                      e.target.value,
                  })
                }
                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white outline-none"
              />

              <button
                onClick={
                  editingUser
                    ? handleUpdateUser
                    : handleAddUser
                }
                className="
                  mt-4 w-full rounded-2xl
                  bg-gradient-to-r
                  from-blue-500 to-purple-600
                  py-4 font-semibold text-white
                "
              >
                {editingUser
                  ? "Update User"
                  : "Add User"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ManageUsers;