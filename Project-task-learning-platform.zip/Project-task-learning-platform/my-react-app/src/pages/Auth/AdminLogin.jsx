import { Link, useNavigate } from "react-router-dom";

import { useState } from "react";

import {
  ShieldCheck,
  Lock,
  Mail,
  ArrowRight,
  Eye,
  EyeOff,
  Activity,
  Database,
} from "lucide-react";

import { motion } from "framer-motion";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

const gradientText =
  "bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent";

const inputWrapper =
  "flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur-xl transition-all duration-300 focus-within:border-cyan-400";

function AdminLogin() {
  const navigate = useNavigate();

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [showPassword, setShowPassword] =
    useState(false);

  /* ================= LOGIN ================= */

  const handleLogin = (e) => {
    e.preventDefault();

    if (
      email === "admin@uptoskills.com" &&
      password === "admin123"
    ) {
      localStorage.setItem(
        "role",
        "admin"
      );

      localStorage.setItem(
        "isLoggedIn",
        "true"
      );

      navigate("/admin-dashboard");
    } else {
      alert(
        "Invalid Admin Credentials\n\nDemo:\nadmin@uptoskills.com\nadmin123"
      );
    }
  };

  return (
    <div
      className="
        relative flex min-h-screen
        items-center justify-center
        overflow-hidden
        bg-[#050816]
        px-4 py-10
      "
    >
      {/* BACKGROUND GLOW */}

      <div className="absolute -left-24 top-0 h-[320px] w-[320px] rounded-full bg-cyan-500/20 blur-[120px]" />

      <div className="absolute -bottom-24 right-0 h-[320px] w-[320px] rounded-full bg-purple-500/20 blur-[120px]" />

      {/* LOGIN CARD */}

      <motion.div
        initial={{
          opacity: 0,
          y: 30,
        }}
        animate={{
          opacity: 1,
          y: 0,
        }}
        transition={{
          duration: 0.6,
        }}
        className={`
          relative z-10
          w-full max-w-md overflow-hidden
          rounded-[32px]
          shadow-[0_0_50px_rgba(59,130,246,0.18)]
          ${glass}
        `}
      >
        {/* TOP BAR */}

        <div className="h-1.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500" />

        {/* CONTENT */}

        <div className="p-6 md:p-7">
          {/* BADGE */}

          <div
            className={`
              mb-5 inline-flex items-center gap-2
              rounded-full px-3 py-1.5
              ${glass}
            `}
          >
            <ShieldCheck
              size={15}
              className="text-cyan-400"
            />

            <span className="text-sm font-medium text-cyan-400">
              Secure Admin Portal
            </span>
          </div>

          {/* HEADING */}

          <h1 className="mb-3 text-2xl font-bold leading-tight md:text-4xl">
            <span className="text-white">
              Admin
            </span>

            <span className={gradientText}>
              {" "}Control Hub
            </span>
          </h1>

          {/* DESCRIPTION */}

          <p className="mb-6 text-sm leading-6 text-slate-400">
            Monitor platform analytics,
            manage instructors, and
            control the AI learning ecosystem.
          </p>

          {/* FEATURE CARDS */}

          <div className="mb-6 grid grid-cols-2 gap-4">
            {/* CARD 1 */}

            <div
              className={`
                rounded-2xl p-4
                ${glass}
              `}
            >
              <div
                className="
                  mb-3 flex h-11 w-11
                  items-center justify-center
                  rounded-xl
                  bg-cyan-500/10
                "
              >
                <Activity className="text-cyan-400" size={20} />
              </div>

              <h3 className="mb-1 text-sm font-semibold text-white">
                Live Analytics
              </h3>

              <p className="text-xs leading-5 text-slate-400">
                Real-time platform insights.
              </p>
            </div>

            {/* CARD 2 */}

            <div
              className={`
                rounded-2xl p-4
                ${glass}
              `}
            >
              <div
                className="
                  mb-3 flex h-11 w-11
                  items-center justify-center
                  rounded-xl
                  bg-purple-500/10
                "
              >
                <Database className="text-purple-400" size={20} />
              </div>

              <h3 className="mb-1 text-sm font-semibold text-white">
                Course Control
              </h3>

              <p className="text-xs leading-5 text-slate-400">
                Manage mentors and courses.
              </p>
            </div>
          </div>

          {/* FORM */}

          <form
            onSubmit={handleLogin}
            className="space-y-4"
          >
            {/* EMAIL */}

            <div>
              <label className="mb-2 block text-sm text-slate-400">
                Admin Email
              </label>

              <div className={inputWrapper}>
                <Mail
                  size={18}
                  className="text-cyan-400"
                />

                <input
                  type="email"
                  placeholder="Enter admin email"
                  value={email}
                  onChange={(e) =>
                    setEmail(
                      e.target.value
                    )
                  }
                  required
                  className="
                    w-full bg-transparent text-sm text-white
                    outline-none
                    placeholder:text-slate-500
                  "
                />
              </div>
            </div>

            {/* PASSWORD */}

            <div>
              <label className="mb-2 block text-sm text-slate-400">
                Password
              </label>

              <div className={inputWrapper}>
                <Lock
                  size={18}
                  className="text-cyan-400"
                />

                <input
                  type={
                    showPassword
                      ? "text"
                      : "password"
                  }
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) =>
                    setPassword(
                      e.target.value
                    )
                  }
                  required
                  className="
                    w-full bg-transparent text-sm text-white
                    outline-none
                    placeholder:text-slate-500
                  "
                />

                <button
                  type="button"
                  onClick={() =>
                    setShowPassword(
                      !showPassword
                    )
                  }
                >
                  {showPassword ? (
                    <EyeOff
                      size={18}
                      className="text-slate-500"
                    />
                  ) : (
                    <Eye
                      size={18}
                      className="text-slate-500"
                    />
                  )}
                </button>
              </div>
            </div>

            {/* LOGIN BUTTON */}

            <button
              type="submit"
              className="
                flex w-full items-center justify-center gap-2
                rounded-2xl
                bg-gradient-to-r
                from-blue-500 to-purple-600
                py-3 text-sm font-semibold text-white
                shadow-[0_0_35px_rgba(59,130,246,0.35)]
                transition-all duration-300
                hover:scale-[1.01]
              "
            >
              Access Dashboard

              <ArrowRight size={18} />
            </button>
          </form>

          {/* DEMO LOGIN */}

          <div
            className="
              mt-5 rounded-xl
              border border-cyan-500/20
              bg-cyan-500/10 p-4
            "
          >
            <h4 className="mb-2 text-base font-semibold text-white">
              Demo Credentials
            </h4>

            <div className="space-y-1 text-sm text-slate-300">
              <p>
                <span className="font-semibold text-cyan-400">
                  Email:
                </span>{" "}
                admin@uptoskills.com
              </p>

              <p>
                <span className="font-semibold text-cyan-400">
                  Password:
                </span>{" "}
                admin123
              </p>
            </div>
          </div>

          {/* FOOTER */}

          <div className="mt-6 text-center text-sm">
            <p className="text-slate-400">
              Student Login?{" "}

              <Link
                to="/login"
                className="
                  font-semibold text-cyan-400
                  transition hover:text-cyan-300
                "
              >
                Go to Student Portal
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default AdminLogin;