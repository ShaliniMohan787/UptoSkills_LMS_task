import { Link, useNavigate } from "react-router-dom";

import { useState } from "react";

import {
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Rocket,
} from "lucide-react";

import { motion } from "framer-motion";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

const gradientText =
  "bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent";

const socialButton =
  "flex items-center justify-center rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white transition-all hover:bg-white/10";

const inputWrapper =
  "flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur-xl transition-all focus-within:border-cyan-400";

function Register() {
  const navigate = useNavigate();

  const [fullName, setFullName] =
    useState("");

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [confirmPassword, setConfirmPassword] =
    useState("");

  const [showPassword, setShowPassword] =
    useState(false);

  const [showConfirmPassword, setShowConfirmPassword] =
    useState(false);

  const [acceptedTerms, setAcceptedTerms] =
    useState(false);

  /* REGISTER */

  const handleRegister = (e) => {
    e.preventDefault();

    /* VALIDATION */

    if (
      password !== confirmPassword
    ) {
      alert(
        "Passwords do not match"
      );

      return;
    }

    if (!acceptedTerms) {
      alert(
        "Please accept Terms & Conditions"
      );

      return;
    }

    /* SAVE USER */

    const userData = {
      fullName,
      email,
      password,
      role: "student",
    };

    localStorage.setItem(
      "user",
      JSON.stringify(userData)
    );

    localStorage.setItem(
      "isLoggedIn",
      "true"
    );

    localStorage.setItem(
      "role",
      "student"
    );

    alert(
      "Registration Successful 🚀"
    );

    navigate("/dashboard");
  };

  return (
    <div
      className="
        relative flex min-h-screen
        items-center justify-center
        overflow-hidden
        bg-[#050816]
        px-4 py-10
      "
    >
      {/* GLOW */}

      <div className="absolute -left-24 -top-24 h-[320px] w-[320px] rounded-full bg-blue-500/20 blur-[120px]" />

      <div className="absolute -bottom-24 right-0 h-[320px] w-[320px] rounded-full bg-pink-500/20 blur-[120px]" />

      {/* CARD */}

      <motion.div
        initial={{
          opacity: 0,
          y: 30,
        }}
        animate={{
          opacity: 1,
          y: 0,
        }}
        transition={{
          duration: 0.6,
        }}
        className={`
          relative z-10
          w-full max-w-md overflow-hidden
          rounded-[32px]
          shadow-[0_0_50px_rgba(59,130,246,0.18)]
          ${glass}
        `}
      >
        {/* TOP BAR */}

        <div className="h-1.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500" />

        {/* CONTENT */}

        <div className="p-6 md:p-7">
          {/* BADGE */}

          <div
            className={`
              mb-5 inline-flex items-center gap-2
              rounded-full px-3 py-1.5
              ${glass}
            `}
          >
            <Sparkles
              size={15}
              className="text-cyan-400"
            />

            <span className="text-sm font-medium text-cyan-400">
              AI Career Platform
            </span>
          </div>

          {/* HEADING */}

          <h1 className="mb-3 text-2xl font-bold leading-tight md:text-4xl">
            <span className="text-white">
              Create
            </span>

            <span className={gradientText}>
              {" "}Account
            </span>
          </h1>

          {/* SUBTITLE */}

          <p className="mb-6 text-sm leading-6 text-slate-400">
            Join futuristic AI learning
            experiences and immersive
            mentor-led courses.
          </p>

          {/* SOCIAL LOGIN */}

          <div className="mb-5 grid grid-cols-2 gap-3">
            <button className={socialButton}>
              Google
            </button>

            <button className={socialButton}>
              Github
            </button>
          </div>

          {/* DIVIDER */}

          <div className="mb-5 flex items-center gap-3">
            <div className="h-[1px] flex-1 bg-white/10" />

            <span className="text-[10px] tracking-wider text-slate-500">
              REGISTER WITH EMAIL
            </span>

            <div className="h-[1px] flex-1 bg-white/10" />
          </div>

          {/* FORM */}

          <form
            onSubmit={handleRegister}
            className="space-y-4"
          >
            {/* FULL NAME */}

            <div>
              <label className="mb-2 block text-sm text-slate-400">
                Full Name
              </label>

              <div className={inputWrapper}>
                <User
                  size={18}
                  className="text-cyan-400"
                />

                <input
                  type="text"
                  placeholder="Enter full name"
                  value={fullName}
                  onChange={(e) =>
                    setFullName(
                      e.target.value
                    )
                  }
                  required
                  className="
                    w-full bg-transparent text-sm text-white
                    outline-none placeholder:text-slate-500
                  "
                />
              </div>
            </div>

            {/* EMAIL */}

            <div>
              <label className="mb-2 block text-sm text-slate-400">
                Email Address
              </label>

              <div className={inputWrapper}>
                <Mail
                  size={18}
                  className="text-cyan-400"
                />

                <input
                  type="email"
                  placeholder="Enter email"
                  value={email}
                  onChange={(e) =>
                    setEmail(
                      e.target.value
                    )
                  }
                  required
                  className="
                    w-full bg-transparent text-sm text-white
                    outline-none placeholder:text-slate-500
                  "
                />
              </div>
            </div>

            {/* PASSWORDS */}

            <div className="grid gap-4 md:grid-cols-2">
              {/* PASSWORD */}

              <div>
                <label className="mb-2 block text-sm text-slate-400">
                  Password
                </label>

                <div className={inputWrapper}>
                  <Lock
                    size={18}
                    className="text-cyan-400"
                  />

                  <input
                    type={
                      showPassword
                        ? "text"
                        : "password"
                    }
                    placeholder="Password"
                    value={password}
                    onChange={(e) =>
                      setPassword(
                        e.target.value
                      )
                    }
                    required
                    className="
                      w-full bg-transparent text-sm text-white
                      outline-none placeholder:text-slate-500
                    "
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setShowPassword(
                        !showPassword
                      )
                    }
                  >
                    {showPassword ? (
                      <EyeOff
                        size={16}
                        className="text-slate-500"
                      />
                    ) : (
                      <Eye
                        size={16}
                        className="text-slate-500"
                      />
                    )}
                  </button>
                </div>
              </div>

              {/* CONFIRM PASSWORD */}

              <div>
                <label className="mb-2 block text-sm text-slate-400">
                  Confirm
                </label>

                <div className={inputWrapper}>
                  <Lock
                    size={18}
                    className="text-cyan-400"
                  />

                  <input
                    type={
                      showConfirmPassword
                        ? "text"
                        : "password"
                    }
                    placeholder="Confirm"
                    value={confirmPassword}
                    onChange={(e) =>
                      setConfirmPassword(
                        e.target.value
                      )
                    }
                    required
                    className="
                      w-full bg-transparent text-sm text-white
                      outline-none placeholder:text-slate-500
                    "
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setShowConfirmPassword(
                        !showConfirmPassword
                      )
                    }
                  >
                    {showConfirmPassword ? (
                      <EyeOff
                        size={16}
                        className="text-slate-500"
                      />
                    ) : (
                      <Eye
                        size={16}
                        className="text-slate-500"
                      />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* TERMS */}

            <div className="flex items-start gap-3 pt-1">
              <input
                type="checkbox"
                checked={acceptedTerms}
                onChange={(e) =>
                  setAcceptedTerms(
                    e.target.checked
                  )
                }
                className="mt-1 h-4 w-4 accent-cyan-400"
              />

              <p className="text-xs leading-6 text-slate-400">
                I agree to Terms &
                Conditions and Privacy
                Policy
              </p>
            </div>

            {/* BUTTON */}

            <button
              type="submit"
              className="
                flex w-full items-center justify-center gap-2
                rounded-2xl
                bg-gradient-to-r
                from-blue-500 to-purple-600
                py-3 text-sm font-semibold text-white
                shadow-[0_0_35px_rgba(59,130,246,0.35)]
                transition-all duration-300
                hover:scale-[1.01]
              "
            >
              <Rocket size={18} />

              Create Account

              <ArrowRight size={18} />
            </button>
          </form>

          {/* FOOTER */}

          <div className="mt-6 text-center text-sm">
            <p className="text-slate-400">
              Already have an account?{" "}

              <Link
                to="/login"
                className="
                  font-semibold text-cyan-400
                  hover:text-cyan-300
                "
              >
                Login
              </Link>
            </p>
          </div>

          {/* SECURITY */}

          <div
            className="
              mt-6 flex items-start gap-3
              rounded-2xl
              border border-green-500/20
              bg-green-500/10 p-4
            "
          >
            <ShieldCheck
              size={18}
              className="mt-1 text-green-400"
            />

            <div>
              <h4 className="mb-1 text-sm font-semibold text-white">
                Secure Registration
              </h4>

              <p className="text-xs leading-6 text-slate-400">
                Protected with encrypted
                authentication systems.
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default Register;