import { Link, useNavigate } from "react-router-dom";

import { useState } from "react";

import {
  Mail,
  Lock,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Eye,
  EyeOff,
  GraduationCap,
} from "lucide-react";

import { motion } from "framer-motion";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

const gradientText =
  "bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent";

const inputWrapper =
  "flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur-xl transition-all focus-within:border-cyan-400";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [showPassword, setShowPassword] =
    useState(false);

  /* LOGIN */

  const handleLogin = (e) => {
    e.preventDefault();

    localStorage.setItem(
      "role",
      "student"
    );

    localStorage.setItem(
      "isLoggedIn",
      "true"
    );

    navigate("/dashboard");
  };

  return (
    <div
      className="
        relative flex min-h-screen
        items-center justify-center
        overflow-hidden
        bg-[#050816]
        px-4 py-10
      "
    >
      {/* GLOW */}

      <div className="absolute -left-24 -top-28 h-[320px] w-[320px] rounded-full bg-blue-500/20 blur-[120px]" />

      <div className="absolute -bottom-28 -right-24 h-[320px] w-[320px] rounded-full bg-pink-500/20 blur-[120px]" />

      {/* CARD */}

      <motion.div
        initial={{
          opacity: 0,
          y: 30,
        }}
        animate={{
          opacity: 1,
          y: 0,
        }}
        transition={{
          duration: 0.6,
        }}
        className={`
          relative z-10
          w-full max-w-md overflow-hidden
          rounded-[32px]
          shadow-[0_0_50px_rgba(59,130,246,0.18)]
          ${glass}
        `}
      >
        {/* TOP BAR */}

        <div className="h-1.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500" />

        {/* CONTENT */}

        <div className="p-6 md:p-7">
          {/* BADGE */}

          <div
            className={`
              mb-5 inline-flex items-center gap-2
              rounded-full px-3 py-1.5
              ${glass}
            `}
          >
            <Sparkles
              size={15}
              className="text-cyan-400"
            />

            <span className="text-sm font-medium text-cyan-400">
              Student Learning Portal
            </span>
          </div>

          {/* HEADING */}

          <h1 className="mb-3 text-2xl font-bold leading-tight md:text-4xl">
            <span className="text-white">
              Student
            </span>

            <span className={gradientText}>
              {" "}Login
            </span>
          </h1>

          {/* DESCRIPTION */}

          <p className="mb-6 text-sm leading-6 text-slate-400">
            Continue your AI learning
            journey with immersive projects
            and futuristic mentorship.
          </p>

          {/* FORM */}

          <form
            onSubmit={handleLogin}
            className="space-y-4"
          >
            {/* EMAIL */}

            <div>
              <label className="mb-2 block text-sm text-slate-400">
                Email Address
              </label>

              <div className={inputWrapper}>
                <Mail
                  size={18}
                  className="text-cyan-400"
                />

                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) =>
                    setEmail(
                      e.target.value
                    )
                  }
                  className="
                    w-full bg-transparent text-sm text-white
                    outline-none placeholder:text-slate-500
                  "
                />
              </div>
            </div>

            {/* PASSWORD */}

            <div>
              <div className="mb-2 flex items-center justify-between">
                <label className="text-sm text-slate-400">
                  Password
                </label>

                <Link
                  to="/forgot-password"
                  className="text-xs text-cyan-400 hover:text-cyan-300"
                >
                  Forgot Password?
                </Link>
              </div>

              <div className={inputWrapper}>
                <Lock
                  size={18}
                  className="text-cyan-400"
                />

                <input
                  type={
                    showPassword
                      ? "text"
                      : "password"
                  }
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) =>
                    setPassword(
                      e.target.value
                    )
                  }
                  className="
                    w-full bg-transparent text-sm text-white
                    outline-none placeholder:text-slate-500
                  "
                />

                <button
                  type="button"
                  onClick={() =>
                    setShowPassword(
                      !showPassword
                    )
                  }
                >
                  {showPassword ? (
                    <EyeOff
                      size={18}
                      className="text-slate-500"
                    />
                  ) : (
                    <Eye
                      size={18}
                      className="text-slate-500"
                    />
                  )}
                </button>
              </div>
            </div>

            {/* LOGIN BUTTON */}

            <button
              type="submit"
              className="
                flex w-full items-center justify-center gap-2
                rounded-2xl
                bg-gradient-to-r
                from-blue-500 to-purple-600
                py-3 text-sm font-semibold text-white
                shadow-[0_0_35px_rgba(59,130,246,0.35)]
                transition-all duration-300
                hover:scale-[1.01]
              "
            >
              Login as Student

              <ArrowRight size={18} />
            </button>
          </form>

          {/* EXTRA LOGIN OPTIONS */}

          <div className="mt-5 space-y-3">
            {/* ADMIN */}

            <button
              onClick={() =>
                navigate("/admin-login")
              }
              className="
                flex w-full items-center justify-center gap-3
                rounded-2xl
                border border-white/10
                bg-white/5
                py-3 text-sm font-medium text-white
                transition-all duration-300
                hover:bg-white/10
              "
            >
              <ShieldCheck size={18} />

              Admin Login
            </button>

            {/* INSTRUCTOR */}

            <button
              onClick={() =>
                navigate(
                  "/instructor-login"
                )
              }
              className="
                flex w-full items-center justify-center gap-3
                rounded-2xl
                border border-white/10
                bg-white/5
                py-3 text-sm font-medium text-white
                transition-all duration-300
                hover:bg-white/10
              "
            >
              <GraduationCap size={18} />

              Instructor Login
            </button>
          </div>

          {/* FOOTER */}

          <div className="mt-6 text-center text-sm">
            <p className="text-slate-400">
              Don’t have an account?{" "}

              <Link
                to="/register"
                className="font-semibold text-cyan-400 hover:text-cyan-300"
              >
                Create Account
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default Login;