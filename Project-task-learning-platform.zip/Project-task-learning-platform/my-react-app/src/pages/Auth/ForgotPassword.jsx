import {
  Mail,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  LockKeyhole,
} from "lucide-react";

import { motion } from "framer-motion";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

const gradientText =
  "bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent";

function ForgotPassword() {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#050816] px-6 py-16">
      
      {/* Background Glow */}
      <div className="absolute -left-24 -top-28 h-[400px] w-[400px] rounded-full bg-blue-500/20 blur-[140px]" />

      <div className="absolute -bottom-28 -right-24 h-[400px] w-[400px] rounded-full bg-pink-500/20 blur-[140px]" />

      {/* Card */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className={`
          relative z-10 w-full max-w-xl overflow-hidden
          rounded-[36px] shadow-[0_0_60px_rgba(59,130,246,0.18)]
          ${glass}
        `}
      >
        
        {/* Top Gradient */}
        <div className={`h-2 ${gradientText}`} />

        {/* Content */}
        <div className="p-10 md:p-14">
          
          {/* Badge */}
          <div className={`mb-8 inline-flex items-center gap-2 rounded-full px-4 py-2 ${glass}`}>
            
            <Sparkles
              size={16}
              className="text-cyan-400"
            />

            <span className="font-medium text-cyan-400">
              Secure Account Recovery
            </span>
          </div>

          {/* Icon */}
          <div className="mb-10 flex h-24 w-24 items-center justify-center rounded-[28px] bg-gradient-to-r from-blue-500 to-purple-600 shadow-[0_0_40px_rgba(59,130,246,0.35)]">
            <LockKeyhole size={42} />
          </div>

          {/* Title */}
<h1 className="mb-4 text-3xl font-bold leading-tight tracking-tight md:text-4xl">            
            <span className="text-white">
              Forgot
            </span>

            <span className={gradientText}>
              {" "}Password
            </span>
          </h1>

          {/* Subtitle */}
          <p className="mb-10 text-base leading-7 text-slate-400">
            Enter your registered email address
            and we’ll send you secure instructions
            to reset your password instantly.
          </p>

          {/* Form */}
          <form className="space-y-7">
            
            {/* Email */}
            <div>
              
              <label className="mb-3 block text-sm text-slate-400">
                Email Address
              </label>

              <div className={`flex items-center gap-4 rounded-2xl px-5 py-5 transition-all focus-within:border-cyan-400 ${glass}`}>
                
                <Mail
                  size={22}
                  className="text-cyan-400"
                />

                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full bg-transparent text-white outline-none placeholder:text-slate-500"
                />
              </div>
            </div>

            {/* Button */}
            <button className="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-600 py-5 text-base font-semibold text-white shadow-[0_0_40px_rgba(59,130,246,0.35)] transition-all duration-300 hover:scale-[1.02]">
              
              Send Reset Link

              <ArrowRight size={20} />
            </button>
          </form>

          {/* Security Note */}
          <div className="mt-10 flex items-start gap-4 rounded-2xl border border-green-500/20 bg-green-500/10 p-5">
            
            <ShieldCheck
              size={24}
              className="mt-1 text-green-400"
            />

            <div>
              
              <h4 className="mb-2 text-sm font-semibold text-white">
                Secure Password Reset
              </h4>

              <p className="leading-7 text-slate-400">
                Your account security is protected
                with encrypted password recovery
                and verified email authentication.
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default ForgotPassword;