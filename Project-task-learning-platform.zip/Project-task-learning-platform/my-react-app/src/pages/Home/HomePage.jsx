import HeroBanner from "../../components/Hero/HeroBanner";

import CourseGrid from "../../components/Course/CourseGrid";

function HomePage() {
  return (
    <div className="bg-slate-50 min-h-screen">

      {/* ================= HERO SECTION ================= */}
      <HeroBanner />

      {/* ================= COURSE SECTION ================= */}
      <CourseGrid />

      {/* ================= WHY CHOOSE US ================= */}
     <section className="relative overflow-hidden bg-[#050816] py-28">
  
  {/* Background Glow */}
  <div className="absolute -left-32 top-0 h-[400px] w-[400px] rounded-full bg-blue-500/20 blur-[120px]" />

  <div className="absolute -right-32 bottom-0 h-[400px] w-[400px] rounded-full bg-pink-500/20 blur-[120px]" />

  <div className="relative z-10 mx-auto max-w-[1500px] px-6">
    
    {/* Heading */}
    <div className="mx-auto mb-20 max-w-3xl text-center">
      
      {/* Badge */}
      <div
        className="
          mb-6 inline-flex items-center gap-2
          rounded-full border border-white/10
          bg-white/5 px-5 py-2
          backdrop-blur-xl
        "
      >
        <span className="h-2 w-2 rounded-full bg-cyan-400" />

        <span className="font-medium text-cyan-400">
          Why Students Love LearnSphere
        </span>
      </div>

      {/* Title */}
      <h2
        className="
          mb-6 text-4xl font-extrabold
          leading-tight tracking-tight
          text-white md:text-5xl
        "
      >
        Learn AI Through
        <span
          className="
            bg-gradient-to-r
            from-cyan-400 via-blue-500 to-purple-500
            bg-clip-text text-transparent
          "
        >
          {" "}Real Experience
        </span>
      </h2>

      {/* Subtitle */}
      <p className="text-lg leading-8 text-slate-400">
        Master practical AI skills with immersive projects,
        mentorship from industry experts, and career-focused
        learning designed for the modern AI ecosystem.
      </p>
    </div>

    {/* Cards */}
    <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
      
      {/* Card 1 */}
      <div
        className="
          group rounded-[32px]
          border border-white/10
          bg-white/5 p-8
          backdrop-blur-2xl
          transition-all duration-500
          hover:-translate-y-2
          hover:border-cyan-400/30
        "
      >
        
        {/* Icon */}
        <div
          className="
            mb-7 flex h-16 w-16 items-center justify-center
            rounded-2xl
            bg-gradient-to-r
            from-cyan-500 to-blue-500
            text-3xl shadow-[0_0_30px_rgba(34,211,238,0.35)]
          "
        >
          🚀
        </div>

        {/* Title */}
        <h3 className="mb-4 text-2xl font-bold text-white">
          Industry Projects
        </h3>

        {/* Description */}
        <p className="leading-8 text-slate-400">
          Build real AI applications used in startups,
          enterprise systems, and production-scale workflows.
        </p>
      </div>

      {/* Card 2 */}
      <div
        className="
          group rounded-[32px]
          border border-white/10
          bg-white/5 p-8
          backdrop-blur-2xl
          transition-all duration-500
          hover:-translate-y-2
          hover:border-purple-400/30
        "
      >
        
        {/* Icon */}
        <div
          className="
            mb-7 flex h-16 w-16 items-center justify-center
            rounded-2xl
            bg-gradient-to-r
            from-purple-500 to-pink-500
            text-3xl shadow-[0_0_30px_rgba(168,85,247,0.35)]
          "
        >
          🎓
        </div>

        {/* Title */}
        <h3 className="mb-4 text-2xl font-bold text-white">
          Expert Mentorship
        </h3>

        {/* Description */}
        <p className="leading-8 text-slate-400">
          Learn directly from experienced AI engineers,
          researchers, and industry professionals.
        </p>
      </div>

      {/* Card 3 */}
      <div
        className="
          group rounded-[32px]
          border border-white/10
          bg-white/5 p-8
          backdrop-blur-2xl
          transition-all duration-500
          hover:-translate-y-2
          hover:border-pink-400/30
        "
      >
        
        {/* Icon */}
        <div
          className="
            mb-7 flex h-16 w-16 items-center justify-center
            rounded-2xl
            bg-gradient-to-r
            from-pink-500 to-orange-500
            text-3xl shadow-[0_0_30px_rgba(236,72,153,0.35)]
          "
        >
          💼
        </div>

        {/* Title */}
        <h3 className="mb-4 text-2xl font-bold text-white">
          Career Support
        </h3>

        {/* Description */}
        <p className="leading-8 text-slate-400">
          Get resume reviews, interview preparation,
          portfolio guidance, and placement assistance.
        </p>
      </div>
    </div>
  </div>
</section>

      {/* ================= TESTIMONIALS ================= */}
      <section className="py-24 bg-slate-900 text-white">

        <div className="max-w-7xl mx-auto px-6">

          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-5">
              Student Success Stories
            </h2>

            <p className="text-slate-400">
              Thousands of learners transformed their careers.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">

            {/* Testimonial */}
            <div className="bg-slate-800 p-8 rounded-3xl">

              <p className="text-slate-300 leading-7 mb-6">
                “The courses helped me transition from a
                software developer to an AI engineer within
                6 months.”
              </p>

              <div className="flex items-center gap-4">

                <img
                  src="https://i.pravatar.cc/100?img=1"
                  alt="student"
                  className="w-14 h-14 rounded-full"
                />

                <div>
                  <h4 className="font-semibold">
                    Priya Sharma
                  </h4>

                  <p className="text-slate-400 text-sm">
                    AI Engineer
                  </p>
                </div>

              </div>
            </div>

            {/* Testimonial */}
            <div className="bg-slate-800 p-8 rounded-3xl">

              <p className="text-slate-300 leading-7 mb-6">
                “Hands-on projects and mentorship made learning
                incredibly practical and engaging.”
              </p>

              <div className="flex items-center gap-4">

                <img
                  src="https://i.pravatar.cc/100?img=5"
                  alt="student"
                  className="w-14 h-14 rounded-full"
                />

                <div>
                  <h4 className="font-semibold">
                    Rahul Verma
                  </h4>

                  <p className="text-slate-400 text-sm">
                    Data Scientist
                  </p>
                </div>

              </div>
            </div>

            {/* Testimonial */}
            <div className="bg-slate-800 p-8 rounded-3xl">

              <p className="text-slate-300 leading-7 mb-6">
                “The best AI learning platform for beginners
                and professionals alike.”
              </p>

              <div className="flex items-center gap-4">

                <img
                  src="https://i.pravatar.cc/100?img=8"
                  alt="student"
                  className="w-14 h-14 rounded-full"
                />

                <div>
                  <h4 className="font-semibold">
                    Sneha Kapoor
                  </h4>

                  <p className="text-slate-400 text-sm">
                    ML Engineer
                  </p>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ================= CTA SECTION ================= */}
     <section className="relative overflow-hidden bg-[#050816] py-28">
  
  {/* Background Glow */}
  <div className="absolute left-0 top-0 h-[350px] w-[350px] rounded-full bg-blue-500/20 blur-[120px]" />

  <div className="absolute bottom-0 right-0 h-[350px] w-[350px] rounded-full bg-purple-500/20 blur-[120px]" />

  {/* Main */}
  <div className="relative z-10 mx-auto max-w-[1200px] px-6 text-center">
    
    {/* Badge */}
    <div
      className="
        mb-6 inline-flex items-center gap-2
        rounded-full border border-white/10
        bg-white/5 px-5 py-2
        backdrop-blur-xl
      "
    >
      <span className="h-2 w-2 rounded-full bg-cyan-400" />

      <span className="font-medium text-cyan-400">
        Build The Future With AI
      </span>
    </div>

    {/* Heading */}
    <h2
      className="
        mb-6 text-4xl font-extrabold
        leading-tight tracking-tight
        text-white md:text-6xl
      "
    >
      Start Your
      <span
        className="
          bg-gradient-to-r
          from-cyan-400 via-blue-500 to-purple-500
          bg-clip-text text-transparent
        "
      >
        {" "}AI Journey
      </span>
      <br />
      Today 🚀
    </h2>

    {/* Description */}
    <p
      className="
        mx-auto mb-10 max-w-3xl
        text-lg leading-8 text-slate-400
      "
    >
      Join thousands of learners mastering Artificial
      Intelligence, Machine Learning, Deep Learning,
      and Generative AI through immersive real-world learning.
    </p>

    {/* Buttons */}
    <div className="flex flex-wrap items-center justify-center gap-5">
      
      {/* Primary */}
      <button
        className="
          rounded-2xl
          bg-gradient-to-r
          from-blue-500 to-purple-600
          px-8 py-4
          font-semibold text-white
          shadow-[0_0_40px_rgba(59,130,246,0.35)]
          transition-all duration-300
          hover:scale-105
        "
      >
        Explore Courses
      </button>

      {/* Secondary */}
      <button
        className="
          rounded-2xl border border-white/10
          bg-white/5 px-8 py-4
          font-medium text-white
          backdrop-blur-xl
          transition-all duration-300
          hover:bg-white/10
        "
      >
        Watch Demo
      </button>
    </div>

    {/* Stats */}
    <div className="mt-16 grid gap-6 md:grid-cols-3">
      
      {/* Stat 1 */}
      <div
        className="
          rounded-3xl border border-white/10
          bg-white/5 p-7
          backdrop-blur-xl
        "
      >
        <h3 className="mb-2 text-4xl font-extrabold text-cyan-400">
          50K+
        </h3>

        <p className="text-slate-400">
          Active Learners
        </p>
      </div>

      {/* Stat 2 */}
      <div
        className="
          rounded-3xl border border-white/10
          bg-white/5 p-7
          backdrop-blur-xl
        "
      >
        <h3 className="mb-2 text-4xl font-extrabold text-purple-400">
          120+
        </h3>

        <p className="text-slate-400">
          AI Courses
        </p>
      </div>

      {/* Stat 3 */}
      <div
        className="
          rounded-3xl border border-white/10
          bg-white/5 p-7
          backdrop-blur-xl
        "
      >
        <h3 className="mb-2 text-4xl font-extrabold text-pink-400">
          95%
        </h3>

        <p className="text-slate-400">
          Placement Success
        </p>
      </div>
    </div>
  </div>
</section>

    </div>
  );
}

export default HomePage;