import {
  BookOpen,
  Trophy,
  BrainCircuit,
  ArrowRight,
  PlayCircle,
  CheckCircle2,
  Sparkles,
  Flame,
} from "lucide-react";

import { motion } from "framer-motion";

import { Link } from "react-router-dom";

import {
  useEffect,
  useState,
} from "react";

/* IMPORT COURSES */
import allMentors from "../../data/allMentors";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

function StatCard({ item }) {
  const Icon = item.icon;

  return (
    <motion.div
      whileHover={{ y: -4 }}
      className={`
        rounded-3xl p-6 transition-all duration-300
        hover:bg-white/[0.07]
        ${glass}
      `}
    >
      <div
        className={`
          mb-5 flex h-14 w-14 items-center
          justify-center rounded-2xl
          ${item.bg}
        `}
      >
        <Icon
          size={26}
          className={item.color}
        />
      </div>

      <p className="mb-2 text-sm text-slate-400">
        {item.title}
      </p>

      <h3 className="text-3xl font-bold text-white">
        {item.value}
      </h3>
    </motion.div>
  );
}

function CourseCard({ course }) {
  return (
    <motion.div
      whileHover={{ y: -6 }}
      className="
        group flex h-full flex-col
        overflow-hidden rounded-[32px]
        border border-white/10
        bg-white/5
        backdrop-blur-2xl
        transition-all duration-500
      "
    >
      {/* IMAGE */}
      <div className="relative overflow-hidden">
        <img
          src={course.image}
          alt={course.title}
          className="
            h-[240px] w-full object-cover
            transition-transform duration-700
            group-hover:scale-105
          "
        />

        <div className="absolute inset-0 bg-gradient-to-t from-[#050816] via-transparent to-transparent" />
      </div>

      {/* CONTENT */}
      <div className="flex flex-1 flex-col p-7">
        <div className="mb-4">
          <p className="text-sm text-cyan-400">
            {course.mentor}
          </p>

          <h3 className="mt-2 text-xl font-bold leading-tight text-white md:text-2xl">
            {course.title}
          </h3>
        </div>

        {/* PROGRESS */}
        <div className="mb-8">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-slate-400">
              Progress
            </span>

            <span className="font-semibold text-cyan-400">
              {course.progress}%
            </span>
          </div>

          <div className="h-3 overflow-hidden rounded-full bg-white/5">
            <div
              className="
                h-full rounded-full
                bg-gradient-to-r
                from-cyan-400 to-blue-500
              "
              style={{
                width: `${course.progress}%`,
              }}
            />
          </div>
        </div>

        {/* BUTTON */}
        <div className="mt-auto">
          <Link to={`/courses/${course.id}`}>
            <button
              className="
                flex w-full items-center
                justify-center gap-2
                rounded-2xl
                bg-gradient-to-r
                from-blue-500 to-purple-600
                py-3 text-sm font-medium
                text-white
                shadow-[0_0_30px_rgba(59,130,246,0.35)]
                transition-all duration-300
                hover:scale-[1.02]
              "
            >
              <PlayCircle size={18} />

              Continue Learning

              <ArrowRight size={18} />
            </button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

function StudentDashboard() {
  const [recentCourses, setRecentCourses] =
    useState([]);

  const [stats, setStats] = useState([]);

  useEffect(() => {
    /* GET ENROLLED IDS */
    const enrolledCourses =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    /* FIX ARRAY / OBJECT ISSUE */
    const mentorsArray =
      Array.isArray(allMentors)
        ? allMentors
        : Object.keys(allMentors).map(
            (key) => ({
              id: Number(key),
              ...allMentors[key],
            })
          );

    /* FILTER ONLY ENROLLED COURSES */
    const enrolledMentors =
      mentorsArray.filter((course) =>
        enrolledCourses.includes(
          course.id
        )
      );

    /* BUILD COURSE DATA */
    const coursesData =
      enrolledMentors.map((course) => {
        const completedModules =
          JSON.parse(
            localStorage.getItem(
              `course-progress-${course.id}`
            )
          ) || [];

        const modules =
          course.modules || [];

        const progress =
          modules.length > 0
            ? Math.round(
                (completedModules.length /
                  modules.length) *
                  100
              )
            : 0;

        return {
          id: course.id,

          title:
            course.title ||
            course.course,

          mentor:
            course.mentor,

          image:
            course.image ||
            course.mentorImage,

          progress,
        };
      });

    setRecentCourses(coursesData);

    /* CALCULATE STATS */

    const completedCourses =
      coursesData.filter(
        (course) =>
          course.progress === 100
      );

    const overallScore =
      coursesData.length > 0
        ? Math.round(
            coursesData.reduce(
              (acc, course) =>
                acc + course.progress,
              0
            ) / coursesData.length
          )
        : 0;

    setStats([
      {
        icon: BookOpen,

        title:
          "Enrolled Courses",

        value:
          enrolledMentors.length.toString(),

        color:
          "text-cyan-400",

        bg:
          "bg-cyan-500/10",
      },

      {
        icon: CheckCircle2,

        title: "Completed",

        value:
          completedCourses.length.toString(),

        color:
          "text-green-400",

        bg:
          "bg-green-500/10",
      },

      {
        icon: Trophy,

        title:
          "Certificates",

        value:
          completedCourses.length.toString(),

        color:
          "text-yellow-400",

        bg:
          "bg-yellow-500/10",
      },

      {
        icon: BrainCircuit,

        title:
          "Skill Score",

        value: `${overallScore}%`,

        color:
          "text-pink-400",

        bg:
          "bg-pink-500/10",
      },
    ]);
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050816] px-6 py-10 lg:px-10">
      {/* GLOW */}
      <div className="absolute -left-32 -top-32 h-[450px] w-[450px] rounded-full bg-blue-500/20 blur-[140px]" />

      <div className="absolute -bottom-32 -right-32 h-[450px] w-[450px] rounded-full bg-pink-500/20 blur-[140px]" />

      {/* MAIN */}
      <div className="relative z-10 mx-auto max-w-[1500px]">
        {/* HEADER */}
        <div className="mb-14 flex flex-col justify-between gap-8 xl:flex-row xl:items-center">
          {/* LEFT */}
          <div>
            <div
              className={`
                mb-6 inline-flex items-center
                gap-2 rounded-full
                px-4 py-2 ${glass}
              `}
            >
              <Sparkles
                size={16}
                className="text-cyan-400"
              />

              <span className="font-medium text-cyan-400">
                AI Learning Dashboard
              </span>
            </div>

            <h1 className="mb-5 text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
              <span className="text-white">
                Welcome Back,
              </span>

              <br />

              <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
                Shalini 👋
              </span>
            </h1>

            <p className="max-w-3xl text-base leading-8 text-slate-400 md:text-lg">
              Continue learning from legendary mentors,
              innovators, creators, athletes, and AI pioneers.
            </p>
          </div>

          {/* STREAK */}
          <div
            className={`
              rounded-[30px]
              px-7 py-6 ${glass}
            `}
          >
            <div className="flex items-center gap-5">
              <div
                className="
                  flex h-16 w-16 items-center
                  justify-center rounded-2xl
                  bg-gradient-to-r
                  from-orange-500 to-pink-500
                  shadow-[0_0_35px_rgba(249,115,22,0.35)]
                "
              >
                <Flame size={28} />
              </div>

              <div>
                <p className="mb-1 text-slate-500">
                  Learning Streak
                </p>

                <h3 className="text-3xl font-bold text-white">
                  24 Days
                </h3>
              </div>
            </div>
          </div>
        </div>

        {/* STATS */}
        <div className="mb-14 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((item) => (
            <StatCard
              key={item.title}
              item={item}
            />
          ))}
        </div>

        {/* COURSES */}
        <div>
          <div className="mb-8">
            <h2 className="mb-3 text-3xl font-bold text-white">
              Continue Learning
            </h2>

            <p className="text-slate-400">
              Resume your learning journey
            </p>
          </div>

          {/* EMPTY */}
          {recentCourses.length === 0 ? (
            <div
              className={`
                rounded-[32px]
                p-16 text-center
                ${glass}
              `}
            >
              <BookOpen
                size={60}
                className="mx-auto mb-6 text-cyan-400"
              />

              <h2 className="mb-4 text-3xl font-bold">
                No Enrolled Courses
              </h2>

              <p className="mb-8 text-slate-400">
                Enroll in a course to begin
                your legendary learning journey 🚀
              </p>

              <Link to="/courses">
                <button
                  className="
                    rounded-2xl
                    bg-gradient-to-r
                    from-cyan-500 to-blue-600
                    px-8 py-4
                    font-semibold
                  "
                >
                  Explore Courses
                </button>
              </Link>
            </div>
          ) : (
            <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
              {recentCourses.map(
                (course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                  />
                )
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default StudentDashboard;