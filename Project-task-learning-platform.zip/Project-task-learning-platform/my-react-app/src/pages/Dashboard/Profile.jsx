import {
  Camera,
  Mail,
  Phone,
  User,
  Lock,
  Globe,
  Sparkles,
  ShieldCheck,
  BrainCircuit,
  Trophy,
  BookOpen,
  Save,
} from "lucide-react";

import { motion } from "framer-motion";

const stats = [
  {
    icon: BookOpen,
    value: "12",
    label: "Courses",
    color: "text-cyan-400",
  },
  {
    icon: Trophy,
    value: "6",
    label: "Awards",
    color: "text-yellow-400",
  },
  {
    icon: BrainCircuit,
    value: "18",
    label: "Skills",
    color: "text-pink-400",
  },
];



const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

const inputStyle =
  "w-full bg-transparent text-white outline-none placeholder:text-slate-500";

const inputWrapper =
  "flex items-center gap-4 rounded-2xl border border-white/10 bg-[#0B1120] px-5 py-4";

const sectionTitle =
  "text-3xl md:text-4xl font-bold text-white";

function Profile() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050816] px-6 py-10 lg:px-10">
      
      {/* Background Glow */}
      <div className="absolute -left-24 -top-24 h-[450px] w-[450px] rounded-full bg-blue-500/20 blur-[140px]" />

      <div className="absolute -bottom-24 -right-24 h-[450px] w-[450px] rounded-full bg-pink-500/20 blur-[140px]" />

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-[1700px]">
        
        {/* Header */}
        <div className="mb-14 flex flex-col justify-between gap-8 xl:flex-row xl:items-center">
          
          {/* Left */}
          <div>
            
            {/* Badge */}
            <div className={`mb-6 inline-flex items-center gap-2 rounded-full px-4 py-2 ${glass}`}>
              
              <Sparkles
                size={16}
                className="text-cyan-400"
              />

              <span className="font-medium text-cyan-400">
                AI Learner Profile
              </span>
            </div>

            {/* Title */}
            <h1 className="mb-5 text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
              
              <span className="text-white">
                My
              </span>

              <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
                {" "}Profile
              </span>
            </h1>

            {/* Subtitle */}
            <p className="max-w-3xl text-base leading-8 text-slate-400 md:text-lg">
              Manage your AI learning identity,
              certifications, skills, and personal
              information in one futuristic dashboard.
            </p>
          </div>

          {/* Save Button */}
          <button className="flex items-center gap-3 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-600 px-8 py-4 font-semibold text-white shadow-[0_0_40px_rgba(59,130,246,0.35)] transition-all duration-300 hover:scale-105">
            
            <Save size={18} />

            Save Changes
          </button>
        </div>

        {/* Grid */}
        <div className="grid gap-10 xl:grid-cols-[380px_1fr]">
          
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className={`overflow-hidden rounded-[36px] ${glass} h-fit`}
          >
            
            {/* Cover */}
            <div className="h-36 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500" />

            {/* Content */}
            <div className="px-7 pb-8">
              
              {/* Avatar */}
              <div className="relative -mt-14 mb-8">
                
                <img
                  src="https://i.pravatar.cc/300"
                  alt="profile"
                  className="h-28 w-28 rounded-[28px] border-[5px] border-[#050816] object-cover"
                />

                {/* Camera */}
                <button className="absolute bottom-2 right-2 flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg">
                  
                  <Camera size={16} />
                </button>
              </div>

              {/* User */}
              <h2 className="mb-2 text-2xl font-bold text-white">
                John Doe
              </h2>

              <p className="mb-8 font-medium text-cyan-400">
                AI Engineer & ML Researcher
              </p>

              {/* Stats */}
              <div className="mb-10 grid grid-cols-3 gap-4">
                
                {stats.map((item) => {
                  const Icon = item.icon;

                  return (
                    <div
                      key={item.label}
                      className={`rounded-2xl p-4 text-center ${glass}`}
                    >
                      
                      <Icon
                        size={20}
                        className={`mx-auto mb-3 ${item.color}`}
                      />

                      <h4 className="text-xl font-bold text-white">
                        {item.value}
                      </h4>

                      <p className="text-sm text-slate-500">
                        {item.label}
                      </p>
                    </div>
                  );
                })}
              </div>

            </div>
          </motion.div>

          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className={`rounded-[36px] p-8 lg:p-10 ${glass}`}
          >
            
            {/* Header */}
            <div className="mb-10">
              
              <h3 className={`${sectionTitle} mb-3`}>
                Personal Information
              </h3>

              <p className="text-base text-slate-400 md:text-lg">
                Update your account details and AI learner profile
              </p>
            </div>

            {/* Form */}
            <form className="space-y-7">
              
              {/* Row 1 */}
              <div className="grid gap-6 md:grid-cols-2">
                
                {/* Full Name */}
                <div>
                  
                  <label className="mb-3 block text-sm text-slate-400">
                    Full Name
                  </label>

                  <div className={inputWrapper}>
                    
                    <User
                      size={20}
                      className="text-cyan-400"
                    />

                    <input
                      type="text"
                      defaultValue="John Doe"
                      className={inputStyle}
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  
                  <label className="mb-3 block text-sm text-slate-400">
                    Email Address
                  </label>

                  <div className={inputWrapper}>
                    
                    <Mail
                      size={20}
                      className="text-cyan-400"
                    />

                    <input
                      type="email"
                      defaultValue="john@gmail.com"
                      className={inputStyle}
                    />
                  </div>
                </div>
              </div>

              {/* Row 2 */}
              <div className="grid gap-6 md:grid-cols-2">
                
                {/* Phone */}
                <div>
                  
                  <label className="mb-3 block text-sm text-slate-400">
                    Phone Number
                  </label>

                  <div className={inputWrapper}>
                    
                    <Phone
                      size={20}
                      className="text-cyan-400"
                    />

                    <input
                      type="text"
                      placeholder="+91 9876543210"
                      className={inputStyle}
                    />
                  </div>
                </div>

                {/* Website */}
                <div>
                  
                  <label className="mb-3 block text-sm text-slate-400">
                    Portfolio Website
                  </label>

                  <div className={inputWrapper}>
                    
                    <Globe
                      size={20}
                      className="text-cyan-400"
                    />

                    <input
                      type="text"
                      placeholder="yourwebsite.com"
                      className={inputStyle}
                    />
                  </div>
                </div>
              </div>

              {/* Bio */}
              <div>
                
                <label className="mb-3 block text-sm text-slate-400">
                  Bio
                </label>

                <textarea
                  rows="5"
                  placeholder="Tell us about yourself..."
                  className="
                    w-full resize-none rounded-2xl
                    border border-white/10
                    bg-[#0B1120]
                    px-5 py-5
                    text-white outline-none
                    placeholder:text-slate-500
                  "
                />
              </div>

              {/* Password */}
              <div className="rounded-[30px] border border-white/10 bg-[#0B1120] p-8">
                
                <div className="mb-8 flex items-center gap-4">
                  
                  <Lock
                    size={26}
                    className="text-cyan-400"
                  />

                  <div>
                    
                    <h3 className="mb-1 text-2xl font-bold text-white">
                      Change Password
                    </h3>

                    <p className="text-slate-500">
                      Keep your account secure
                    </p>
                  </div>
                </div>

                {/* Inputs */}
                <div className="grid gap-6 md:grid-cols-2">
                  
                  <input
                    type="password"
                    placeholder="New Password"
                    className="
                      rounded-2xl border border-white/10
                      bg-white/5 px-5 py-4
                      text-white outline-none
                      placeholder:text-slate-500
                    "
                  />

                  <input
                    type="password"
                    placeholder="Confirm Password"
                    className="
                      rounded-2xl border border-white/10
                      bg-white/5 px-5 py-4
                      text-white outline-none
                      placeholder:text-slate-500
                    "
                  />
                </div>
              </div>

              {/* Security */}
              <div className="flex items-start gap-4 rounded-2xl border border-green-500/20 bg-green-500/10 p-5">
                
                <ShieldCheck
                  size={22}
                  className="mt-1 text-green-400"
                />

                <div>
                  
                  <h4 className="mb-2 text-sm font-semibold text-white">
                    Secure Profile Management
                  </h4>

                  <p className="leading-7 text-slate-400">
                    Your profile information is encrypted
                    and securely protected with enterprise-grade
                    security systems.
                  </p>
                </div>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default Profile;