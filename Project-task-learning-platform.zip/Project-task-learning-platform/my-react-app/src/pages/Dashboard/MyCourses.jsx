import {
  PlayCircle,
  ArrowRight,
  Trash2,
  BookOpen,
  Sparkles,
  BarChart3,
} from "lucide-react";

import { motion } from "framer-motion";

import { Link } from "react-router-dom";

import { useEffect, useState } from "react";

import allMentors from "../../data/allMentors";

const glass =
  "border border-white/10 bg-white/5 backdrop-blur-xl";

function MyCourses() {
  const [myCourses, setMyCourses] =
    useState([]);

  /* =========================
     FIX ARRAY / OBJECT ISSUE
  ========================== */

  const mentorsArray = Array.isArray(allMentors)
    ? allMentors
    : Object.keys(allMentors).map((key) => ({
        id: Number(key),
        ...allMentors[key],
      }));

  /* LOAD ENROLLED COURSES */

  useEffect(() => {
    const enrolled =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    const filteredCourses =
      mentorsArray.filter((course) =>
        enrolled.includes(course.id)
      );

    setMyCourses(filteredCourses);
  }, []);

  /* REMOVE COURSE */

  const removeCourse = (courseId) => {
    const enrolled =
      JSON.parse(
        localStorage.getItem(
          "enrolledCourses"
        )
      ) || [];

    const updatedEnrolled =
      enrolled.filter(
        (id) => id !== courseId
      );

    localStorage.setItem(
      "enrolledCourses",
      JSON.stringify(updatedEnrolled)
    );

    setMyCourses((prev) =>
      prev.filter(
        (course) =>
          course.id !== courseId
      )
    );
  };

  /* CALCULATE OVERALL PROGRESS */

  const overallProgress =
    myCourses.length > 0
      ? Math.round(
          myCourses.reduce(
            (acc, course) => {
              const progress =
                JSON.parse(
                  localStorage.getItem(
                    `course-progress-${course.id}`
                  )
                ) || [];

              const modules =
                course.modules || [];

              const percentage =
                modules.length > 0
                  ? (progress.length /
                      modules.length) *
                    100
                  : 0;

              return acc + percentage;
            },
            0
          ) / myCourses.length
        )
      : 0;

  return (
    <div
      className="
        min-h-screen
        bg-[#050816]
        px-6 py-10
        text-white
      "
    >
      <div className="mx-auto max-w-7xl">
        {/* HERO */}

        <div className="mb-14">
          <div
            className={`
              mb-5 inline-flex
              items-center gap-2
              rounded-full
              px-4 py-2
              ${glass}
            `}
          >
            <Sparkles
              size={16}
              className="text-cyan-400"
            />

            <span className="text-cyan-400">
              Personalized AI Learning
            </span>
          </div>

          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1
                className="
                  text-5xl
                  font-black
                  leading-tight
                "
              >
                My{" "}
                <span
                  className="
                    bg-gradient-to-r
                    from-cyan-400
                    via-blue-500
                    to-purple-500
                    bg-clip-text
                    text-transparent
                  "
                >
                  Courses
                </span>
              </h1>

              <p
                className="
                  mt-5 max-w-3xl
                  text-lg
                  leading-8
                  text-slate-400
                "
              >
                Track your learning
                progress, continue
                immersive sessions,
                and master elite
                skills from legendary
                mentors.
              </p>
            </div>

            {/* OVERALL PROGRESS */}

            <div
              className={`
                flex items-center gap-5
                rounded-3xl
                p-8 ${glass}
              `}
            >
              <div
                className="
                  flex h-20 w-20
                  items-center justify-center
                  rounded-3xl
                  bg-gradient-to-r
                  from-blue-500
                  to-purple-600
                "
              >
                <BarChart3 size={32} />
              </div>

              <div>
                <p className="text-slate-400">
                  Overall Progress
                </p>

                <h2 className="text-5xl font-black">
                  {overallProgress}%
                </h2>
              </div>
            </div>
          </div>
        </div>

        {/* EMPTY STATE */}

        {myCourses.length === 0 && (
          <motion.div
            initial={{
              opacity: 0,
              y: 40,
            }}
            animate={{
              opacity: 1,
              y: 0,
            }}
            className={`
              flex flex-col
              items-center
              justify-center
              rounded-[40px]
              p-20 text-center
              ${glass}
            `}
          >
            <div
              className="
                mb-8 flex
                h-28 w-28
                items-center
                justify-center
                rounded-full
                bg-gradient-to-r
                from-cyan-500/20
                to-purple-500/20
              "
            >
              <BookOpen
                size={50}
                className="text-cyan-400"
              />
            </div>

            <h2 className="mb-4 text-4xl font-black">
              No Courses Enrolled
            </h2>

            <p
              className="
                mb-8 max-w-xl
                text-lg
                leading-8
                text-slate-400
              "
            >
              Your learning vault is
              currently empty.
              Enroll in courses and
              begin your AI mastery
              journey 🚀
            </p>

            <Link to="/courses">
              <button
                className="
                  flex items-center gap-2
                  rounded-2xl
                  bg-gradient-to-r
                  from-cyan-500
                  to-blue-600
                  px-8 py-4
                  font-semibold
                  transition-all
                  hover:scale-105
                "
              >
                Explore Courses

                <ArrowRight size={20} />
              </button>
            </Link>
          </motion.div>
        )}

        {/* COURSE GRID */}

        {myCourses.length > 0 && (
          <div
            className="
              grid gap-8
              md:grid-cols-2
              xl:grid-cols-3
            "
          >
            {myCourses.map(
              (course, index) => {
                const completed =
                  JSON.parse(
                    localStorage.getItem(
                      `course-progress-${course.id}`
                    )
                  ) || [];

                const modules =
                  course.modules || [];

                const progress =
                  modules.length > 0
                    ? Math.round(
                        (completed.length /
                          modules.length) *
                          100
                      )
                    : 0;

                return (
                  <motion.div
                    key={course.id}
                    initial={{
                      opacity: 0,
                      y: 40,
                    }}
                    animate={{
                      opacity: 1,
                      y: 0,
                    }}
                    transition={{
                      delay:
                        index * 0.1,
                    }}
                    whileHover={{
                      y: -8,
                    }}
                    className={`
                      overflow-hidden
                      rounded-[36px]
                      ${glass}
                    `}
                  >
                    {/* IMAGE */}

                    <div className="relative">
                      <img
                        src={
                          course.image
                        }
                        alt={
                          course.title
                        }
                        className="
                          h-[260px]
                          w-full
                          object-cover
                        "
                      />

                      <div
                        className="
                          absolute inset-0
                          bg-gradient-to-t
                          from-[#050816]
                          via-transparent
                          to-transparent
                        "
                      />

                      <div
                        className="
                          absolute left-5 top-5
                          rounded-full
                          bg-black/40
                          px-4 py-2
                          text-sm
                          backdrop-blur-xl
                        "
                      >
                        {
                          course.category
                        }
                      </div>
                    </div>

                    {/* CONTENT */}

                    <div className="p-7">
                      {/* MENTOR */}

                      <div className="mb-5 flex items-center gap-4">
                        <img
                          src={
                            course.mentorImage ||
                            course.image
                          }
                          alt={
                            course.mentor
                          }
                          className="
                            h-14 w-14
                            rounded-full
                            object-cover
                          "
                        />

                        <div>
                          <h3 className="font-bold">
                            {
                              course.mentor
                            }
                          </h3>

                          <p className="text-sm text-slate-400">
                            {course.role ||
                              "AI Mentor"}
                          </p>
                        </div>
                      </div>

                      {/* TITLE */}

                      <h2
                        className="
                          mb-4 text-2xl
                          font-black
                          leading-tight
                        "
                      >
                        {course.title ||
                          course.course}
                      </h2>

                      {/* PROGRESS */}

                      <div className="mb-6">
                        <div
                          className="
                            mb-2 flex
                            items-center
                            justify-between
                          "
                        >
                          <span className="text-slate-400">
                            Progress
                          </span>

                          <span className="font-bold text-cyan-400">
                            {progress}%
                          </span>
                        </div>

                        <div className="h-3 rounded-full bg-white/10">
                          <div
                            className="
                              h-full rounded-full
                              bg-gradient-to-r
                              from-cyan-400
                              to-blue-500
                            "
                            style={{
                              width: `${progress}%`,
                            }}
                          />
                        </div>
                      </div>

                      {/* BUTTONS */}

                      <div className="flex gap-4">
                        <Link
                          to={`/courses/${course.id}`}
                          className="flex-1"
                        >
                          <button
                            className="
                              flex w-full
                              items-center
                              justify-center
                              gap-2
                              rounded-2xl
                              bg-gradient-to-r
                              from-blue-500
                              to-purple-600
                              px-5 py-3
                              font-medium
                              transition-all
                              hover:scale-105
                            "
                          >
                            <PlayCircle
                              size={18}
                            />

                            Continue
                          </button>
                        </Link>

                        <button
                          onClick={() =>
                            removeCourse(
                              course.id
                            )
                          }
                          className="
                            flex items-center
                            justify-center
                            rounded-2xl
                            border border-red-500/20
                            bg-red-500/10
                            px-5
                            text-red-400
                            transition-all
                            hover:bg-red-500/20
                          "
                        >
                          <Trash2
                            size={20}
                          />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              }
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default MyCourses;